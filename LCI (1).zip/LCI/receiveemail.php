
<?php





$key="KuaPcAFhBMSGYlH3E5Q62ILom" //your unique API key;
$message=urlencode($message) //encode url;
$url=" http://sumafo.sinitsolutions.org/api/sendemail.php?key=KuaPcAFhBMSGYlH3E5Q62ILom&emailsender=xxxxxx@example.com&emailsendername=xxxxxxxxxxx&subject=xxxxxxxxx&message=xxxxxxxxxxxxx&emailreceiver=xxxxxxx@example.com&emailreceivername=xxxxxxxxxxxxxxx&datetime=yyyy-mm-dd ";
$result=file_get_contents($url); //call url and store result; 
switch($result){ 
case "successful": 
echo "Message sent";
break;
case "failed":
echo "Message not sent";
break;
case "insufficient balance": 
echo "You don't have enough balance";
break;
case "invalid API key": 
echo "Invalid API Key";
break; 
}
?>