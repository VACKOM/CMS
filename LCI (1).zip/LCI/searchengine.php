<!DOCTYPE HTML>



<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    
    <body>
<div data-role="page" id="searchMenu" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Search Engine</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
        
    </div>
    
     <div data-role="content">

        <ol data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Sub Menu</li>
            <li><a href= "#CustID">Search by ID Number</a></li>
            <li><a href= "#CustName">Search by Name</a></li>      
            <li><a href= "">Search by Branch</a></li>
            <li><a href= "#CustRegDate">Search by Date</a></li>
            <li><a href= "#CustRegMon">Search by Month</a></li>
            <li><a href= "#CustRegYear">Search by Year</a></li>
            <li><a href= "">Search by Product</a></li>
            <li><a href= "">View Photo Album</a></li>
        </ol>
    
        </div>
    
    
    <div data-role="footer" data-position="fixed">
        
        <h2>&copy; All Rights reserved. 2014</h2>
    </div>
    
  </div>

    
    
 <!--Page for Customer ID Search-->

        
        
<div data-role="page" id="CustID" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>ID Number Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Enter Customer ID Number for Search</h4>
                <br>
                    
                <input type="text" id ="CIdSearch" name="CIdSearch" value =""  
                   placeholder="Customer ID Number.....">
                    <br>
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>
        
        
         <!--Page for Customer Name Search-->

        
        
<div data-role="page" id="CustName" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Name Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Enter Customer Name for Search</h4>
                <br>
                    
                <input type="text" id ="CNSearch" name="CNSearch" value =""  
                   placeholder="Customer Name.....">
                    <br>
                 
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>
        
        
        
        
 <!--Page for Customer Month Date Search-->

        
        
<div data-role="page" id="CustRegDate" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Name Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Select Date of Registration for Search</h4>
                <br>
                    
                <input type="date" id ="CRDSearch" name="CRDSearch" value =""  
                   placeholder="Registration Date.....">
                    <br>
                 
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>
        
        
         <!--Page for Customer Month Search-->
        
        
 <div data-role="page" id="CustRegMon" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Name Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Enter Month and Year of Registration for Search</h4>
                <br>
                    
                <input type="text" id ="CRMSearch" name="CRMSearch" value =""  
                   placeholder="Registration Month (eg May = 05)">
                    <br>
                 <input type="text" id ="CRYSearch" name="CRYSearch" value =""  
                   placeholder="Registration Year (eg 2014)">
                    <br>
                 
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>    
        
        
        
        <!-- Page for Customer Year Seach-->
        
        
        
        <div data-role="page" id="CustRegYear" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Name Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Enter Year of Registration for Search</h4>
                <br>
                    
                
                 <input type="text" id ="CRYYSearch" name="CRYYSearch" value =""  
                   placeholder="Registration Year (eg 2014)">
                    <br>
                 
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>    
        
        
    </body>
</html>