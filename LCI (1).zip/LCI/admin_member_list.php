<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
 
if (login_check($mysqli) == true) {
   // echo "logged in ooooooooo";
    $logged = 'in';
} else {
    $logged = 'out';
   // echo "logged out kmmmm";
   header('Location: index.php');
}
?>



<!DOCTYPE HTML>

<html>
<head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   
    
     
<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';

session_start();

$Chapel =$_SESSION['username'];
$Count = 0;
    

$records = array();

if($results = mysqli_query($db,"SELECT * FROM membersfile")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}
$counting = '0';

$John = '0';
$Joel = '0';
$Romans = '0';
$Hebrews = '0';
$Peter = '0';
$Corinthians = '0';
$Jude = '0';
$Genesis = '0';
$Philemon = '0';
$Samuel= '0';
$Nehemiah = '0';
$Phillipians = '0';
$Ephesians = '0';
$Galatians = '0';
$Colossians = '0';
$Luke = '0';
$Mark = '0';
$James = '0';
$Acts = '0';
$Timothy = '0';
$Exodus = '0';

$Matthew = '0';
$Joshua = '0';
$numberholder="0000000000";

 foreach($records as $r){
     //echo ($r->thanks);
 $counting++;


if($r->CBranch == "John"){
     $John++;
    }
   else if($r->CBranch == "Joel"){
     $Joel++;
    }
   else if($r->CBranch == "Romans"){
     $Romans++;
    } 
    else if($r->CBranch == "Hebrews"){
     $Hebrews++;
    } 
     else if($r->CBranch == "Peter"){
     $Peter++;
    } 
     else if($r->CBranch == "Corinthians"){
     $Corinthians++;
    } 
    else if($r->CBranch == "Jude"){
     $Jude++;
    } 
    else if($r->CBranch == "Genesis"){
     $Genesis++;
    } 
     else if($r->CBranch == "Philemon"){
     $Philemon++;
    } 
    else if($r->CBranch == "Samuel"){
     $Samuel++;
    } 
    else if($r->CBranch == "Nehemiah"){
     $Nehemiah++;
    } 
    else if($r->CBranch == "Phillipians"){
     $Phillipians++;
    }
    else if($r->CBranch == "Ephesians"){
     $Ephesians++;
    } 
    else if($r->CBranch == "Galatians"){
     $Galatians++;
    }
     else if($r->CBranch == "James"){
     $James++;
    }
    
     else if($r->CBranch == "Colossians"){
     $Colossians++;
    }
    else if($r->CBranch == "Luke"){
     $Luke++;
    }
    else if($r->CBranch == "Mark"){
     $Mark++;
    }
    
    else if($r->CBranch == "Acts"){
     $Acts++;
    }
    else if($r->CBranch == "Timothy"){
     $Timothy++;
    }
    else if($r->CBranch == "Exodus"){
     $Exodus++;
    }
     else if($r->CBranch == "Matthew"){
     $Matthew++;
    }
    else if($r->CBranch == "Joshua"){
     $Joshua++;
    }
 }
?>


     
       
       
</head>
    <body>
        
    <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Error Logging In!</p>';
        }
        ?> 
<div data-role="page" id="schedule" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Members List</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "admin_mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     <div data-role="content">
       
        
        <ol data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Chapel Members List</li>
            <li><a href= "#John" data-ajax="false">John Chapel<span class="ui-li-count"><?php echo ($John); ?></span></a></li>
            
             <li><a href= "#Joel" data-ajax="false">Joel Chapel<span class="ui-li-count"><?php echo ($Joel); ?></span></a></li>
           
            <li><a href= "#Romans" data-ajax="false">Romans Chapel<span class="ui-li-count"><?php echo ($Romans); ?></span></a></li>
            
            <li><a href= "#Hebrews" data-ajax="false">Hebrews Chapel<span class="ui-li-count"><?php echo ($Hebrews); ?></span></a></li>
            
            <li><a href= "#Peter" data-ajax="false">Peter Chapel<span class="ui-li-count"><?php echo ($Peter); ?></span></a></li>
            
            <li><a href= "#Samuel" data-ajax="false">Samuel Chapel<span class="ui-li-count"><?php echo ($Samuel); ?></span></a></li>
            
            <li><a href= "#Jude" data-ajax="false">Jude Chapel<span class="ui-li-count"><?php echo ($Jude); ?></span></a></li>
            
            <li><a href= "#Genesis" data-ajax="false">Genesis Chapel<span class="ui-li-count"><?php echo ($Genesis); ?></span></a></li>
            
            <li><a href= "#Nehemiah" data-ajax="false">Nehemiah Chapel<span class="ui-li-count"><?php echo ($Nehemiah); ?></span></a></li>
            
            <li><a href= "#Phillipians" data-ajax="false">Phillipians Chapel<span class="ui-li-count"><?php echo ($Phillipians); ?></span></a></li>
            
            <li><a href= "#James" data-ajax="false">James Chapel<span class="ui-li-count"><?php echo ($James); ?></span></a></li>
            
            <li><a href= "#Galatians" data-ajax="false">Galatians Chapel<span class="ui-li-count"><?php echo ($Galatians); ?></span></a></li>
            
            <li><a href= "#Philemon" data-ajax="false">Philemon Chapel<span class="ui-li-count"><?php echo ($Philemon); ?></span></a></li>
            
            <li><a href= "#Corinthians" data-ajax="false">Corinthians Chapel<span class="ui-li-count"><?php echo ($Corinthians); ?></span></a></li>
            
            <li><a href= "#Ephesians" data-ajax="false">Ephesians Chapel<span class="ui-li-count"><?php echo ($Ephesians); ?></span></a></li>
            
             <li><a href= "#Colossians" data-ajax="false">Colossians Chapel<span class="ui-li-count"><?php echo ($Colossians); ?></span></a></li>
             
             <li><a href= "#Luke" data-ajax="false">Luke Chapel<span class="ui-li-count"><?php echo ($Luke); ?></span></a></li>
             
             <li><a href= "#Mark" data-ajax="false">Mark Chapel<span class="ui-li-count"><?php echo ($Mark); ?></span></a></li>
             
             
              <li><a href= "#Acts" data-ajax="false">Acts Chapel<span class="ui-li-count"><?php echo ($Acts); ?></span></a></li>
             
             <li><a href= "#Timothy" data-ajax="false">Timothy Chapel<span class="ui-li-count"><?php echo ($Timothy); ?></span></a></li>
             
             <li><a href= "#Exodus" data-ajax="false">Exodus Chapel<span class="ui-li-count"><?php echo ($Exodus); ?></span></a></li>
             
              <li><a href= "#Matthew" data-ajax="false">Matthew Chapel<span class="ui-li-count"><?php echo ($Matthew); ?></span></a></li>
             
             <li><a href= "#Joshua" data-ajax="false">Joshua Chapel<span class="ui-li-count"><?php echo ($Joshua); ?></span></a></li>
            
        
        </ol>
        <br>
        <hr>
        <?php
         print("Total No of Members = ".($counting)."<br/>");
        ?>
        
        
    
        
        </div>
        <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved.</h2>
          </div>
  
    
  </div>
        
 <div data-role="page" id="John" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>John Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "John"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=john\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($John == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of John Members = ".($John)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>    
        
        

        
    
  <div data-role="page" id="Joel" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Joel Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Joel"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=joel\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Joel == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Joel Members = ".($Joel)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>
        
    
  </div> 
  
  
 <div data-role="page" id="Romans" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Romans Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Romans"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=romans\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Romans == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Romans Members = ".($Romans)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>   
  
  
 
   <div data-role="page" id="Hebrews" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Hebrews Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Hebrews"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=hebrews\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Hebrews == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Hebrews Members = ".($Hebrews)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>   
  
  
  
  <div data-role="page" id="Samuel" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Samuel Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Samuel"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=samuel\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Samuel == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Samuel Members = ".($Samuel)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

  </div> 
  
  
  
  <div data-role="page" id="Peter" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Peter Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Peter"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=peter\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Peter == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Peter Members = ".($Peter)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div>  
  
  
  

    <div data-role="page" id="Genesis" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Genesis Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Genesis"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=genesis\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Genesis == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Genesis Members = ".($Genesis)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
   <div data-role="page" id="Jude" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Jude Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Jude"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=jude\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Jude == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Jude Members = ".($Jude)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
   <div data-role="page" id="Nehemiah" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Nehemiah Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Nehemiah"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=nehemiah\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Nehemiah == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Nehemiah Members = ".($Nehemiah)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div>
  
  
  
  
   <div data-role="page" id="Phillipians" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Phillipians Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Phillipians"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=phillipians\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Phillipians == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Phillipians Members = ".($Phillipians)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
     <div data-role="page" id="James" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>James Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "James"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=james\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($James == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of James Members = ".($James)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
       <div data-role="page" id="Galatians" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Galatians Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Galatians"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=galatians\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Galatians == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Galatians Members = ".($Galatians)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
         <div data-role="page" id="Philemon" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Philemon Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Philemon"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=philemon\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Philemon == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Philemon Members = ".($Philemon)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
           <div data-role="page" id="Corinthians" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Corinthians Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Corinthians"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=corinthians\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Corinthians == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Corinthians Members = ".($Corinthians)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
  
    <div data-role="page" id="Ephesians" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Ephesians Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Ephesians"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=ephesians\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Ephesians == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Ephesians Members = ".($Ephesians)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  <div data-role="page" id="Colossians" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Colossians Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Colossians"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=colossians\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Colossians == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Colossians Members = ".($Colossians)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  <div data-role="page" id="Luke" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Luke Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Luke"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=luke\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Luke == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Luke Members = ".($Luke)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  

  
<div data-role="page" id="Mark" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Mark Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Mark"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=mark\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Mark == '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Mark Members = ".($Mark)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
  <div data-role="page" id="Acts" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Acts Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Acts"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=acts\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Acts== '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Acts Members = ".($Acts)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
  <div data-role="page" id="Timothy" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Timothy Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Timothy"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=timothy\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Timothy== '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Timothy Members = ".($Timothy)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  <div data-role="page" id="Exodus" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Exodus Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Exodus"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=exodus\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Exodus== '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Exodus Members = ".($Exodus)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
  
  <div data-role="page" id="Matthew" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Matthew Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Matthew"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=matthew\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Matthew== '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Matthew Members = ".($Matthew)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 
  
  
  
  <div data-role="page" id="Joshua" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Joshua Chapel Members</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "admin_member_list.php" >Entire List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
   
    

     foreach($records as $r){
         
         if($r->CBranch == "Joshua"){
   
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r->Cid)."&activity=joshua\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
 
        
     }
    if($Joshua== '0'){
        echo 'No Members recorded';
         
    }else{
         
        
    }
     }
?>


<br>
<hr>
        <?php
         print("No of Joshua Members = ".($Joshua)."<br/>");
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div> 

  

     <?php
        if (login_check($mysqli) == true) {
                        echo '<p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . ' Chapel'.'.</p>';
 
            echo '<p>Do you want to change user? <a href="includes/logout.php">Log out</a>.</p>';
        } else {
                        echo '<p>Currently logged ' . $logged . '.</p>';
                         echo "<p>If you don't have a login, please <a href='register.php'>register</a></p>";
                }
?>    
        

            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>
  </div> 
  
  
  
    
  
  


    </body>
</html>