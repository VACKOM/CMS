<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
 
if (login_check($mysqli) == true) {
   // echo "logged in ooooooooo";
    $logged = 'in';
} else {
    $logged = 'out';
   // echo "logged out kmmmm";
   header('Location: index.php');
}
?>



<!DOCTYPE HTML>

<html>
<head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   
    
     
<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';

session_start();

$Chapel =$_SESSION['username'];
$Count = 0;
    

$records = array();

if($results = mysqli_query($db,"SELECT * FROM membersfile WHERE CBranch = '$Chapel'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}
$counting = '1';

$thanks = '0';
$welcome = '0';
$birthday = '0';
$message1 = '0';
$message2 = '0';
$message3 = '0';
$message4 = '0';
$message5 = '0';
$message6 = '0';
$message7= '0';
$message8 = '0';
$message9 = '0';
$message10 = '0';
$message11 = '0';
$numberholder="0000000000";

 foreach($records as $r){
     //echo ($r->thanks);
 


if($counting = 1){
     $now = time(); // or your date as well
     $your_date = strtotime($r->thanks);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $thanks++;
    }
   
}
     
     if($counting = 2){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message1);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message1++;
        
    }
   
}
     if($counting = 3){
     $now = time(); // or your date as well
     $your_date = strtotime($r->welcome);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $welcome++;
        
    }
   
}
     
     
     if($counting = 4){
     $now = date("Y-m-d"); // or your date as well
      $CYear = substr($now, 0, 4);//dd
         $CMon = substr($now, 5, 2);//mm
         $CDay = substr($now, 8, 2);//yyyy
    
    $counting ++;
         //echo ($r->BMon);
         
    if(($r->BMon == $CMon)&&($r->BDay == $CDay)&&($r->BYear == $CYear)) {
        $birthday++;
        
    }
   
}
     
     if($counting = 5){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message2);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message2++;
        
    }
   
}
     
     if($counting = 6){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message3);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message3++;
        
    }
   
}
     
      if($counting = 7){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message4);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message4++;
        
    }
   
}
     
      if($counting = 8){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message5);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message5++;
        
    }
   
}
     
      if($counting = 9){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message6);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message6++;
        
    }
   
}
     
     if($counting = 10){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message7);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message7++;
        
    }
   
}
     
     if($counting = 11){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message8);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message8++;
        
    }
   
}
   if($counting = 12){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message9);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message9++;
        
    }
   
}
     
     if($counting = 13){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message10);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message10++;
        
    }
   
}
     
     if($counting = 14){
     $now = time(); // or your date as well
     $your_date = strtotime($r->message11);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank >= 0 ){
        $message11++;
        
    }
   
}
 }
?>


     
       
       
</head>
    <body>
        
    <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Error Logging In!</p>';
        }
        ?> 
<div data-role="page" id="schedule" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Daily Schedules</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     <div data-role="content">
       
        
        <ol data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Daily Activities</li>
        
            <li><a href= "#birthday" data-ajax="false">Birthday List<span class="ui-li-count"><?php echo ($birthday); ?></span></a></li>
        
            <li><a href= "#thankucard" data-ajax="false">Thanks for joining List<span class="ui-li-count"><?php echo ($thanks); ?></span></a></li>
            
             <li><a href= "#welcome" data-ajax="false">Welcome List<span class="ui-li-count"><?php echo ($welcome); ?></span></a></li>
            
             <li><a href= "#message1" data-ajax="false">Member Check Up List 1<span class="ui-li-count"><?php echo ($message1); ?></span></a></li>
             
             <li><a href= "#message2" data-ajax="false">Member Check Up List 2<span class="ui-li-count"><?php echo ($message2); ?></span></a></li>
             
             <li><a href= "#message3" data-ajax="false">Member Check Up List 3<span class="ui-li-count"><?php echo ($message3); ?></span></a></li>
             
             <li><a href= "#message4" data-ajax="false">Member Check Up List 4<span class="ui-li-count"><?php echo ($message4); ?></span></a></li>
             
             <li><a href= "#message5" data-ajax="false">Member Check Up List 5<span class="ui-li-count"><?php echo ($message5); ?></span></a></li>
             
             <li><a href= "#message6" data-ajax="false">Member Check Up List 6<span class="ui-li-count"><?php echo ($message6); ?></span></a></li>
             
             <li><a href= "#message7" data-ajax="false">Member Check Up List 7<span class="ui-li-count"><?php echo ($message7); ?></span></a></li>
             
             <li><a href= "#message8" data-ajax="false">Member Check Up List 8<span class="ui-li-count"><?php echo ($message8); ?></span></a></li>
             
             <li><a href= "#message9" data-ajax="false">Member Check Up List 9<span class="ui-li-count"><?php echo ($message9); ?></span></a></li>
             
             <li><a href= "#message10" data-ajax="false">Member Check Up List 10<span class="ui-li-count"><?php echo ($message10); ?></span></a></li>
             
             <li><a href= "#message11" data-ajax="false">Member Check Up List 11<span class="ui-li-count"><?php echo ($message11); ?></span></a></li>
             
        
        </ol>
        
    
        
        </div>
  
    
  </div>
        
 <div data-role="page" id="thankucard" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Contact List</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php" >Daily Schedules</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $thanks = '0';
;
     foreach($records as $r){
         $Count++;
     $now = time(); // or your date as well
     $your_date = strtotime($r->thanks);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $thanks++;
         
         
                            
           
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=thanksyou\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($thanks == '0'){
        echo 'No Thank you SMS need to be sent today';
         
    }else{
         
        
         echo "Members to be called today = ";
         echo $thanks;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".$numberholder."?\">");                           
        //                      print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
    }
?>


<br>
<hr>
        
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>    
        
        


 <div data-role="page" id="welcome" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Welcome List</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php" >Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $welcome = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->welcome);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $welcome++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=welcome\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                            
                             $test = array('var1'=>$numberholder, 'var2'=>($r->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($welcome== '0'){
        echo 'No Welcome Messages need to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $welcome;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".$numberholder."?\">");                           
        //                      print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>"); 
                    
        //             echo $numberholder;
        
    }
?>
<br>
<hr>
        
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  
        
    
<div data-role="page" id="birthday" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Birthday List</h4>
         
         <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $birthday = '0';

     foreach($records as $r){
         
      $now = date("Y-m-d"); // or your date as well
      $CYear = substr($now, 0, 4);//dd
         $CMon = substr($now, 5, 2);//mm
         $CDay = substr($now, 8, 2);//yyyy
         
    if(($r->BMon == $CMon)&&($r->BDay == $CDay)&&($r->BYear == $CYear)) {
        $birthday++;
         
         print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=birthday\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($birthday== '0'){
        echo 'No Birthday wishes need to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $birthday;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
    }
?>
<br>
<hr>
        
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>    

        
<div data-role="page" id="message1" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 1</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php" >Daily Schedules</a></li>
         </ul>
         </div> 
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message1 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message1);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message1++;
         
         print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=message1\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message1== '0'){
        echo 'No Message to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message1;
        //  print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      

    }
?>
<br>
<hr>
         
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div> 
      
        
<div data-role="page" id="message2" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 2</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message2 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message2);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message2++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=message2\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message2== '0'){
        echo 'No Message need to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message2;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
        
    }
?>
<br>
<hr>
         
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  


<div data-role="page" id="message3" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 3</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message3 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message3);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message3++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."&activity=message3\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message3== '0'){
        echo 'No Message need to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message3;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
    }
?>
<br>
<hr>
        
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  


        
<div data-role="page" id="message4" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 4</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message4= '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message4);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message4++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message4== '0'){
        echo 'No Members need to be contacted today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message4;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
        
    }
?>
<br>
<hr>
             
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  
        
 
<div data-role="page" id="message5" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 5</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message5 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message5);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message5++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message5== '0'){
        echo 'No Members need to be contacted today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message5;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");      
        
    }
?>
<br>
<hr>
         
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  



<div data-role="page" id="message6" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 6</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message6 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message6);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message6++;
         
         print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($survey2== '0'){
        echo 'No Member needs to be contacted today';
       
    }else{
         echo "Members to be contacted today = ";
         echo $message6;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");    
    }
?>
<br>
<hr>
         
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  


<div data-role="page" id="message7" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 7</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message7 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message7);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message7++;
         
         print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message7== '0'){
        echo 'No Member needs to be contacted today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message7;

        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");   
    }
?>
<br>
<hr>
        
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  

        
<div data-role="page" id="message8" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 8</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message8 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message8);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message8++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message8== '0'){
        echo 'No Member needs to be contacted today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message8;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");    
    }
?>
<br>
<hr>
         
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  

        
<div data-role="page" id="message9" data-theme="d">
     <div data-role="header" data-theme="d">
        <h4>Check Up List 9</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message9 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message9);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message9++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message9== '0'){
        echo 'No Member needs to be contacted today';
       
    }else{
         echo "Members to be contacted today = ";
         echo $message9;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");     
    }
?>
<br>
<hr>
        
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div> 
        
        
<div data-role="page" id="message10" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 10</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message10 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message10);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message10++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message10== '0'){
        echo 'No Member needs to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message10;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");  
    }
?>
<br>
<hr>
         
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  
  
  
  <div data-role="page" id="message11" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Check Up List 11</h4>
          <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php">Daily Schedules</a></li>
         </ul>
         </div> 
        
     </div>
    
          <div data-role="content">
              
    <?php
    $tank = '0';
    $message11 = '0';

     foreach($records as $r){
         
     $now = time(); // or your date as well
     $your_date = strtotime($r->message11);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
   
    if($tank >= 0 ){
       $message11++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->Cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"schedulesDetails.php?action=".($r->Cid)."\">");                           
                            print("".($r->CFName)." ".($r->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         
    }else{}
        
     }
    if($message11== '0'){
        echo 'No Member needs to be sent today';
        
    }else{
         echo "Members to be contacted today = ";
         echo $message11;
        //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
        //                     print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
        //                     print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."\">");                           
        //                     print("Send SMS to All <br>");
        //                     print("</a>");
        //                     print("</li>\n");  
                                                
                                              
        //             print("</ul>");  
    }
?>
<br>
<hr>
         
            
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div> 

     <?php
        if (login_check($mysqli) == true) {
                        echo '<p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . ' Chapel'.'.</p>';
 
            echo '<p>Do you want to change user? <a href="includes/logout.php">Log out</a>.</p>';
        } else {
                        echo '<p>Currently logged ' . $logged . '.</p>';
                         echo "<p>If you don't have a login, please <a href='register.php'>register</a></p>";
                }
?>    
        

            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>  
 

    </body>
</html>