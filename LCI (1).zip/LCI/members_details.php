<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';


?>
<!DOCTYPE html>
<html>
<head>
   

    <title> CMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes" />
        
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    
   
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>  
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">  
    
    <script>
    
    $(function() {
$("#caller").click(function() {

var number = window.location.href.slice(-8)
alert(number)
$.ajax({
      type: "POST",
      url: "callerDelete.php",
      data: "CId=" + number,
      success: function(data){  
      window.location.href = "schedules.php#thankucard"
      }

});






   
   });
   
   });
    
    </script>
       
       
</head>
    <body>
    <div data-role="page" id="Home" data-theme="d">        

        <div data-role="header" data-position="fixed">
            <h1>Search Results</h1>
            <div data-role="navbar">
         <ul>
         <li><a href= "members_list.php" data-ajax="false">Members List</a></li>
         </ul>
         </div> 
        </div>
    <div data-role="content">

<?php


$search = $_GET['action'];
$activity = $_GET['activity'];

$records = array();

if($results = mysqli_query($db,"SELECT * FROM membersfile WHERE Cid = '$search'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}


if(! count($records)){
    echo 'No Match Records Found...';
}else{

  
?>


       
        
        <br>
        
        
        <table>
        <thead>
            <tr>
               <th> </th>
               <th> </th>
            
            </tr>
            
        </thead>
        
           
               
            
            <tbody>
                <?php
    foreach($records as $r){
                 ?>
                
                
                
               <tr>
                  <td><b>ID Number:  </b></td>
                  <td><?php echo ($r->Cid); ?></td>
                   
               </tr>
                <?php
                }
                ?>
                
            </tbody>
            
             <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Name:  </b></td>
                  <td><?php echo ($r->CFName); ?>  <?php echo ($r->CLName); ?></td>
               </tr>
                <?php
                }
                ?>
            </tbody>
           
             <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
    		
                 ?>
               <tr>
                  <td><b>Contact:  </b></td>
                  <td id = "caller"><a id = "number" href = "tel:<?php echo ($r->CContact); ?>" > <?php echo ($r->CContact); ?></a></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
           
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Registeration Date:  </b></td>
                  <td><?php echo ($r->RDate); ?></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
        
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Chapel:  </b></td>
                  <td><?php echo ($r->CBranch); ?></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
        <br>
        <br>

        <?php

    //   print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
    //                         // print("<li data-ibm-jquery-contact=\"".($r->CContact)."\">");
    //                         // print("<a data-rel=\"page\" data-transition=\"pop\"href=\"ScheduleSMS.php?action=".($r->CContact)."&firstname=".($r->CFName)."&lastname =".($r->CLName)."&finalactivity='$activity'\">");                           
    //                         // print("Send SMS<br>");
    //                         print("</a>");
    //                         print("</li>\n");  
                                                
                                              
    //                 print("</ul>");      
        
        }

?>
</div>
</div>



</body>

</html>