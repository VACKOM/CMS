<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();

 
if (login_check($mysqli) == true) {
    
    $logged = 'in';
} else {
    $logged = 'out';
   header('Location: index.php');
}
session_start();
$Array = explode("^", $_SESSION['WEB_SES']);
$Service = $Array[0];
 $Date = $Array[1];
 
 //echo $Service;

    
     
     $Count = 0;
        


$Chapel =$_SESSION['username'];
echo $Chapel;
$records = array();

if($results = mysqli_query($db,"SELECT * FROM membersfile WHERE CBranch = '$Chapel'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}





?>



<!DOCTYPE HTML>

<html>
 <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   

    
    
    
     




</head>
    <body>
        <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Error Logging In!</p>';
        }
        ?>   
   <div data-role="page" id="thankucard" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Attendance List</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php" >Dash Board</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
              
           <?php
           
  
     foreach($records as $r){
       $Count++;
        
        ?>
        
             <form action="#" method="post">
            <div class="form-group">
          <fieldset data-role="controlgroup" data-iconpos="right">  

        
         
                <label><input type="checkbox" value="<?php echo ($r->Cid); ?>" id="check_list[]" name="check_list[]" onClick="checkboxes();"> <?php echo ($r->CFName); ?> <?php echo ($r->CLName); ?></label>
        
        
    </fieldset>
        
        <?php
                    
     }
         
         ?>
         <input type = "hidden"  id = "Service" name ="Service" value ="<?php echo ($Service); ?>">
          <input type = "hidden"  id = "ServiceDate" name ="ServiceDate" value ="<?php echo ($Date); ?>"> 
          
           <?php 
           print("No of Chapel members = ".($Count)."<br/>");
          ?>
          
          <input type = "text"  id = "sel" name ="sel" value ="No of attended members = 0"> 
        <br>
<hr>

<input type="submit" name="submit"  value="Save Attandance">
</form>
   <?php
  
   
if(isset($_POST['submit'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
     $DayService = trim($_POST['Service']);
        $ServiceDate = trim($_POST['ServiceDate']);
    
    echo $Cid;
    
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
    $Cid = $selected;
    
    
    if($DayService == "Sunday"){
    
     $insert = $db->prepare("INSERT INTO sunday_attendance (Cid, Date) VALUES (?,?)");
            $insert->bind_param('ss', $Cid,$ServiceDate);
                
     if($insert->execute ()){
               
            //header('Location: index.php');
            }else
            {
                
                
            }
    }else if($DayService == "Wednesday"){
    
     $insert = $db->prepare("INSERT INTO weekday_attendance (Cid, Date) VALUES (?,?)");
            $insert->bind_param('ss', $Cid,$ServiceDate);
                
     if($insert->execute ()){
               
            //header('Location: index.php');
            }else
            {
               
            }
    } 

}

 ?>
                
                
 <script>

setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/LCI/report_generator.php"; 
}, 1000);
alert("Members attendance for this service has been successfully registered");

</script>
                
                
                <?php

}
}

?>
      
      
      
      
      
      
          </div>
           <?php
        if (login_check($mysqli) == true) {
                        echo '<p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . ' Chapel'.'.</p>';
 
            echo '<p>Do you want to change user? <a href="includes/logout.php">Log out</a>.</p>';
        } else {
                        echo '<p>Currently logged ' . $logged . '.</p>';
                         echo "<p>If you don't have a login, please <a href='register.php'>register</a></p>";
                }
?>    
            
          <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>

        
    
  </div>          
              
     </div>         
              
             <script>
                 
                 function checkboxes()
      {
       var inputElems = document.getElementsByTagName("input"),
        count = 0;

        for (var i=0; i<inputElems.length; i++) {       
           if (inputElems[i].type == "checkbox" && inputElems[i].checked == true){
              count++;
              document.getElementById("sel").value = "No of attended members = "+ count;
           }

        }
     }
                 
             </script> 
              
              
                    
        

</body>
</html>