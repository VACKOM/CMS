<?php

	$receiver = htmlentities(isset($_GET['phonenumber']) ? @$_GET['phonenumber'] : @$_POST['phonenumber']);
	$message = htmlentities(isset($_GET['message']) ? @$_GET['message'] : @$_POST['message']);
	$sender = htmlentities(isset($_GET['senderid']) ? @$_GET['senderid'] : @$_POST['senderid']);
	
	
	$key="KuaPcAFhBMSGYlH3E5Q62ILom"; //your unique API key
$message=urlencode($message); //encode url
$url="http://sumafo.sinitsolutions.org/api/sendsms.php?key=KuaPcAFhBMSGYlH3E5Q62ILom&receiver=$receiver&message=$message&sender=$sender";
$result=file_get_contents($url); //call url and store result;
switch($result){ 
case "successful": 
echo "Message sent";
break;
case "failed":
echo "Message not sent";
break;
case "insufficient balance": 
echo "You don't have enough balance";
break;
case "invalid API key": 
echo "Invalid API Key";
break; 
}

	
	
	
	
	
	
	
	?>