<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';


?>
<!DOCTYPE html>
<html>
<head>
   

    <title> CMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes" />
        
 <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    
   
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>  
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    <body>
    <div data-role="content">

<?php
$search = $_GET['action'];

$records = array();

if($results = mysqli_query($db,"SELECT * FROM events WHERE EHead = '$search'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
    
     foreach($records as $r){
       


        
         
         
}
?>
 <label for= "head"><i><center><h2><?php echo ($r->EHead);?></h2></center></i></label>
 <br>
         <label><b>Description:</b></label>
         
         <label for= "head"><i><?php echo ($r->EDes);?></i></label>
    
     
         <hr>
         <br>
         
         <label><b>Organisation:</b></label>
         
         <label for= "or"><i><?php echo ($r->EOrg);?></i></label>
        
         <hr>
         <br>
         
         <label><b>Location:</b></label>
         
         <label for= "loc"><i><?php echo ($r->ELoc);?></i></label>
         <hr>
         
         <br>
         <label><b>Contact Number:</b></label>
         
         <label for= "con"><a href = "tel:<?php echo ($r->ECont); ?>"><i><?php echo ($r->ECont);?></a></i></label>
        
         <hr>
         <br>
         <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="Estart"><b>Starting Date:</b></label>
                       
          <label for= "start"><i><?php echo ($r->EStart);?></i></label>
                      
         <br>   
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
         <br>   
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime1"><b>Starting Time:</b></label>
                       
          <label for= "time1"><i><?php echo ($r->ETime1);?></i></label>
        

      </div>
      
    </div>
         
         <hr>
         <br>
         
           <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="end"><b>Ending Date:</b></label>
                       
          <label for= "endi"><i><?php echo ($r->EEnd);?></i></label>
                      
         <br>   
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
         <br>   
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime2"><b>Ending Time:</b></label>
                       
          <label for= "time2"><i><?php echo ($r->ETime2);?></i></label>
        

      </div>
      
    </div>
         
         <hr>
         <hr>
         <br>
         
         <input type="submit" id ="create" value="Attended">  
    
    </div>

 <?php
}

?>




    </body>
    </html>