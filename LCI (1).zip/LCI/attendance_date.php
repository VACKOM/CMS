<?php 

require 'db/connect.php';
require 'functions/security.php';
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
 
if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
   header('Location: index.php');
}

$Chapel = ($_SESSION['username']);


$records2 = array();

if($results2 = mysqli_query($db,"SELECT DISTINCT Date FROM sunday_attendance ORDER BY Date DESC")){
    
    if($results2->num_rows){
        while($row2 = $results2->fetch_object()){
            $records2[]=$row2;
        }
        $results2->free();
        
    }
    
    
    
    
}

if(! count($records2)){
    echo 'No Match Records Found 1...';
}else{
        
}



?>

<!DOCTYPE HTML>

<html>
<head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
    
    </head>
    
    <body>

<div data-role="page" id="thankucard" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Sunday Service</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "javascript:history.back()" >Attendance List</a></li>
         </ul>
         </div> 
     
         
        
     </div>
    
          <div data-role="content">
              
    <?php

    
     foreach($records2 as $r2){ 
          $column = $r2->Date;
           
           
           
         $records = array();

if($results = mysqli_query($db,"SELECT * FROM sunday_attendance WHERE Date = '$column'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}  


if($Chapel == "Exodus"){
    
    foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "EXODU"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "John"){
    
    foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "JOHN/"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Romans"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "ROMAN"){
    $counting++;
    }
  
    }
 
}
  
else if($Chapel == "Joel"){
    foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "JOEL/"){
    $counting++;
    }
  
    }

}

else if($Chapel == "Hebrews"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "HEBRE"){
    $counting++;
    }
  
    }
    
}

else if($Chapel == "Peter"){
   foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "PETER"){
    $counting++;
    }
  
    }
}

else if($Chapel == "Corinthians"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "CORIN"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Jude"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "JUDE/"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Genesis"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "GENES"){
    $counting++;
    }
  
    }
   
}

else if($Chapel == "Philemon"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "PHILE"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Samuel"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "SAMUE"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Nehemiah"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "NEHEM"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Phillipians"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "PHILL"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Ephesians"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "EPHES"){
    $counting++;
    }
  
    }

}

else if($Chapel == "Galatians"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "GALAT"){
    $counting++;
    }
  
    }
   
}

else if($Chapel == "James"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "JAMES"){
    $counting++;
    }
  
    }
   
}

else if($Chapel == "Colossians"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "COLOS"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Luke"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "LUKE/"){
    $counting++;
    }
  
    }
  
   
}

else if($Chapel == "Mark"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "MARK/"){
    $counting++;
    }
  
    }
  
}

else if($Chapel == "Acts"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "ACTS/"){
    $counting++;
    }
  
    }
 
}

else if($Chapel == "Timothy"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "TIMOT"){
    $counting++;
    }
  
    }
   
}

else if($Chapel == "Matthew"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "MATTH"){
    $counting++;
    }
  
    }
   
}


else if($Chapel == "Joshua"){
     foreach($records as $r){
    $chapelCode = substr($r->Cid ,4,5);
    
    if($chapelCode == "JOSHU"){
    $counting++;
    }
  
    }
   
}    


           
// $Count = 0;


// $counting = '0';

           
           
           
           
           
          
           
      print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r2->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"attendance_report.php?action=".($column)."&activity=thanksyou\">");                           
                            print("".($column)."<br/>");
                             print("<span class=\"ui-li-count\">$counting");
                            print("</span>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r2->Date));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         $counting = 0;
                              
                                              
                    print("</ul>");      
    
         
             
        
     }
   
?>



<br>
<hr>
        
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>    

 </body>
</html>
