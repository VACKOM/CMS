<?php
    //  if(!empty($_POST)){  
$endPoint = 'https://api.mnotify.com/api/sms/quick';        
$apiKey = 'xFpJpR8V3fbMJ07OVtAr1oRZw2KxcihKYHtoyCjCRvpAv';        
$url = $endPoint . '?key=' . $apiKey; 

//  $message= trim($_POST['message']);
//  $phone= trim($_POST['no']);

$data = [        
'recipient' => '0266544154',        
'sender' => 'First&Best',        
'message' => 'Abaaaaaaaa',        
'is_schedule' => 'false',        
'schedule_date' => ''        
];        
$ch = curl_init();        
$headers = array();        
$headers[] = "Content-Type: application/json";        
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);        
curl_setopt($ch, CURLOPT_URL, $url);        
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);        
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");        
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));        
$result = curl_exec($ch);        
$result = json_decode($result, TRUE);        
curl_close($ch);        
//Log::info($result);    
// }
?>