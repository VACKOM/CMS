<?php

require 'db/connect.php';
require 'functions/security.php';

$con=mysqli_connect('localhost','gdatzzhm_databaselciadmin','m{b1m!RhMGCW','gdatzzhm_databaselci');


?>

<!DOCTYPE html>
<html>
 <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   
</head>
    
    <body>
    <div data-role="page" id="register" data-theme="d" >
    
           
    
 <div data-role="content" data-theme="d">

 <button onclick="window.location.href='schedules.php'">Daily Schedules</button>
    <?php
    $phone = htmlentities(isset($_GET['phonenumber']) ? @$_GET['phonenumber'] : @$_POST['phonenumber']);
    $message = htmlentities(isset($_GET['message']) ? @$_GET['message'] : @$_POST['message']);
    $sender_id = htmlentities(isset($_GET['senderid']) ? @$_GET['senderid'] : @$_POST['senderid']);
    $finalactivity = htmlentities(isset($_GET['finalactivity']) ? @$_GET['finalactivity'] : @$_POST['finalactivity']);
    $key="0b780da0f5b5ef17808c"; //your unique API key
//    $message=urlencode($message); //encode url




 

   
   if($finalactivity == "'birthday'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    $BYear = substr($newbirthday, 0, 4);//dd
         
 
 // echo $BYear;
  // echo $phone;
   
 $sql4="UPDATE membersfile SET BYear ='$BYear' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}

  else if($finalactivity == "'thanksyou'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET thanks ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'welcome'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET welcome ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message1'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message1 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message2'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message2 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message3'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message3 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message4'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message4 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message5'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message5 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message6'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message6 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message7'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message7 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message8'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message8 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message9'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message9 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message10'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message10 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}else if($finalactivity == "'message11'"){
   $newbirthday= date( "Y-m-d", strtotime( "$rdate +12 month" ) ); // PHP:  08-03-04
   
    
        //echo  $newbirthday;
 
   
 $sql4="UPDATE membersfile SET message11 ='$newbirthday' WHERE CContact='$phone'";


if ($result4 =mysqli_query($con,$sql4))
  {



    
      $url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$resultsms=file_get_contents($url); //call url and store result;

switch($resultsms){
    case "1000":
    echo "Message sent";
    break;
    case "1002":
    echo "Message not sent";
    break;
    case "1003":
    echo "You don't have enough balance";
    break;
    case "1004":
    echo "Invalid API Key";
    break;
    case "1005":
    echo "Phone number not valid";
    break;
    case "1006":
    echo "Invalid Sender ID";
    break;
    case "1008":
    echo "Empty message";
    break;
}

}

}

?>
</div>
 <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>
</body>
</html>
