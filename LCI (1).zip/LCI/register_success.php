<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
         <title>JSO Customer Platform</title>
         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="css/style4.css">
        
         <style>
           a {
              color: blue;
             }
</style>
    </head>
    <body>
         <div class="container">
             <br>
             <div class="alert alert-success fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
    <strong>Note!</strong> Registration successful!</div>
        
        <h4><i>You can now go back to the <a href="index.php">login page</a> and log in.</i></h4>
        </div>
    </body>
</html>