<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
 
if (login_check($mysqli) == true) {
   // echo "logged in ooooooooo";
    $logged = 'in';
} else {
    $logged = 'out';
   // echo "logged out kmmmm";
   header('Location: index.php');
}
?>

<!DOCTYPE HTML>

<html>
<head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   
    
     
<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';

session_start();

$Chapel =$_SESSION['username'];
$Count = 0;



$records = array();

if($results = mysqli_query($db,"SELECT * FROM Chapels")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}

 
?>


     
       
       
</head>
    <body>
        
    <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Error Logging In!</p>';
        }
        ?> 
<div data-role="page" id="schedule" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Chapels List</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "admin_mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
     <div data-role="content">
                
    <?php
   

     foreach($records as $r){
         
        $Count++;
         
        print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r->cid)."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"chapels_details.php?action=".($r->cid)."\">");         
                            print("".($r->name)."<br/>");
                            print("</a>");
                            print("</li>\n");  
                                                
                                              
                    print("</ul>");      
    
         

        
     }
     
     
     
        
    
?>
<br>
<hr>
        <br>
          
         
          <?php 
           print("No of Chapels = ".($Count)."<br/>");
          ?>
          </div>
          <br>
          
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>

        
    
  </div>  
        
 
        


     <?php
        if (login_check($mysqli) == true) {
                        echo '<p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . ' Chapel'.'.</p>';
 
            echo '<p>Do you want to change user? <a href="includes/logout.php">Log out</a>.</p>';
        } else {
                        echo '<p>Currently logged ' . $logged . '.</p>';
                         echo "<p>If you don't have a login, please <a href='register.php'>register</a></p>";
                }
?>    
        

            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>  
 

    </body>
</html>