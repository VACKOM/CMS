# Introduction

KoolReport is an intuitive and flexible open-source PHP reporting framework for faster and easier report delivery.

# Installation

1. Copy the `koolreport` folder to your web application
2. Start building your report.

# Get started

Please look at [KoolReport Get Started](https://www.koolreport.com/getting-started)

# Support

Please use the Feedback functionality on our website or directly email us at [support@koolreport.com](mailto:support@koolreport.com)