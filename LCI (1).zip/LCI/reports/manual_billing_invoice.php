<?php

session_start();

$Array = explode("^", $_SESSION['WEB_SES']);
 $acc = $Array[0];
 $name = $Array[1];
$mon = $Array[2];
$contact = $Array[3];
$location = $Array[4];
  $billdate= $Array[5];

     $subarea=$Array[6];
    $area= $Array[7];
$sub =   $Array[8];
  $liftdays = $Array[9];
    $prem =$Array[10];
    $rent = $Array[11];
     $lift = $Array[12];
    $nolift = $Array[13];
    $invno= $Array[14];
  $discount= $Array[15];
  $mbill =  $Array[16];
  $bal = $Array[17];
  $baldue = $Array[18];
  
  
  
   
  
  
  

require ('fpdf17/fpdf.php');

// include class
include("Numbers/Words.php");
 
// create object
$nw = new Numbers_Words();



//A4 width : 219mm
//default margin : 10mm each side
//writeable horizontal : 219- (10*2)=189mm

$pdf = new FPDF('p','mm','A4');

$pdf->AddPage();

$width=$pdf -> w; // Width of Current Page
$height=$pdf -> h; // Height of Current Page
$edge=2; // Gap between line and border , change this value

$pdf->Line($edge, $edge,$width-$edge,$edge); // Horizontal line at top
$pdf->Line($edge, $height-$edge,$width-$edge,$height-$edge); // Horizontal line at bottom
$pdf->Line($edge, $edge,$edge,$height-$edge); // Vetical line at left 
$pdf->Line($width-$edge, $edge,$width-$edge,$height-$edge); // Vetical line at Right



//set font to arial, bold, 14pt
$pdf->SetFont('Arial','B',14);

//Cell(width, height, text , border , end line , [align] )
$pdf->Image('jso.png',10,12,25,0,'');
$pdf->Cell(50, 5, '' ,0,0);
$pdf->Cell(140 , 5, 'J. STANLEY-OWUSU GROUP OF COMPANIES' ,0,1);//end of line

//Emty Cell for space
$pdf->Cell(50, 2, '' ,0,1);


//set font to arial regular, 9pt
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 5, '' ,0,0);
$pdf->Cell(140 , 5, 'P.O.BOX 3751, ACCRA' ,0,1);//end of line


//set font to arial regular, 9pt
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 5, '' ,0,0);
$pdf->Cell(140 , 5, 'Location: NO 1. J.STANLEY-OWUSU STREET GP-GA-594, ACCRA-WINNEBA RD' ,0,1);//end of line

//set font to arial regular, 9pt
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 5, '' ,0,0);
$pdf->Cell(140 , 5, 'TEL: +233-302-304883 / +233-207-490901' ,0,1);//end of line


//set font to arial regular, 9pt
$pdf->SetFont('Arial','',9);
$pdf->Cell(50, 5, '' ,0,0);
$pdf->Cell(140 , 5, 'EMAIL: admin@jso-group.com' ,0,1);//end of line

// Ruling a Line across
$pdf->Line(2, 45, 210-2, 45); // 20mm from each edge

//Emty Cell for space
$pdf->Cell(50, 20, '' ,0,1);

//Title
//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',18);
$pdf->Cell(70, 5, '' ,0,0);
$pdf->Cell(90 , 5, 'INVOICE BILL' ,0,1);

//Emty Cell for space
$pdf->Cell(40, 10, '' ,0,1);


//Rect(float x, float y, float w, float h [, string style])
$pdf->Rect(5,65,200,40);

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45, 2, 'Customer Account Number:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(80 , 2, $acc ,0,0);//end of line


//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(33, 2, 'Invoice Number:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(95 , 2, $invno ,0,1);//end of line

//Emty Cell for space
$pdf->Cell(40, 4, '' ,0,1);

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45, 2, 'Customer Name:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(80 , 2, $name ,0,0);//end of line

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(33, 2, 'Invoice Date:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(95 , 2, $billdate ,0,1);//end of line

//Emty Cell for space
$pdf->Cell(40, 4, '' ,0,1);

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45, 2, 'Address:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(80 , 2, $location ,0,0);//end of line

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(33, 2, 'Metro Area:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(95 , 2, $subarea ,0,1);//end of line

//Emty Cell for space
$pdf->Cell(40, 4, '' ,0,1);

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45, 2, 'Contact:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(80 , 2, $contact ,0,0);//end of line

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(33, 2, 'Sub Electoral Area:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(95 , 2, $area ,0,1);//end of line

//Emty Cell for space
$pdf->Cell(40, 4, '' ,0,1);

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(45, 2, 'Description:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(80 , 2, 'Waste Collection For ' . $mon ,0,0);//end of line

//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',9);
$pdf->Cell(33, 2, 'Suburb:' ,0,0);

$pdf->SetFont('Arial','',9);
$pdf->Cell(95 , 2, $sub ,0,1);//end of line

// Ruling a Line to seprate customer information
//Line(float x1, float y1, float x2, float y2)
$pdf->Line(130, 105, 130, 65); // 20mm from each edge

//Emty Cell for space
$pdf->Cell(50, 20, '' ,0,1);

//Title
//set font to arial regular, 9pt
$pdf->SetFont('Arial','B',14);
$pdf->Cell(65, 5, '' ,0,0);
$pdf->Cell(80 , 3, 'DETAILS OF CHARGES' ,0,1);

//-----------Detail of charges Structures starts here ---------------
//Emty Cell for space
$pdf->Cell(40, 10, '' ,0,1);

//Rect(float x, float y, float w, float h [, string style])
// BIG rECT
$pdf->Rect(5,125,200,140);

// Ruling a Line across
//Line(float x1, float y1, float x2, float y2)
// Line ruling the headers
$pdf->Line(5, 138, 210-5, 138); // 20mm from each edge


//Line(float x1, float y1, float x2, float y2)

// Line dividing Amount to the right

$pdf->Line(175, 245, 175, 125); // 20mm from each edge


//Line(float x1, float y1, float x2, float y2)
// Line ruling the description
$pdf->Line(5, 175, 210-5, 175); // 20mm from each edge


//Line(float x1, float y1, float x2, float y2)
// dividing subtotal
$pdf->Line(140, 265, 140, 125); // 20mm from each edge

// dividing Amount in words
//Line(float x1, float y1, float x2, float y2)
$pdf->Line(5, 218, 210-5, 218); // 20mm from each edge

// dividing Signature section
//Line(float x1, float y1, float x2, float y2)
$pdf->Line(5, 245, 210-5, 245); // 20mm from each edge

//Line(float x1, float y1, float x2, float y2)
// dividing description on the right side
$pdf->Line(52, 175, 52, 125); // 20mm from each edge

//Line(float x1, float y1, float x2, float y2)
// dividing site name on the right side
$pdf->Line(73, 175, 73, 125); // 20mm from each edge

//Line(float x1, float y1, float x2, float y2)
// dividing container rentals on the right side
$pdf->Line(96, 175, 96, 125); // 20mm from each edge

//Line(float x1, float y1, float x2, float y2)
// dividing container Lifting on the right side
$pdf->Line(116, 175, 116, 125); // 20mm from each edge

//-----------Detail of charges Structures ends here ---------------

//----------Detail of charges header starts here ---------------------

//set font to arial regular, 12pt
$pdf->SetFont('Arial','B',11);
$pdf->Cell(42, 2, 'Description' ,0,0);
$pdf->Cell(21, 2, 'Site Name' ,0,0);
$pdf->Cell(23, 2, 'Con Rental' ,0,0);
$pdf->Cell(23, 2, 'No of Lift' ,0,0);
$pdf->Cell(27, 2, 'Charges' ,0,0);
$pdf->Cell(40, 2, 'Discount' ,0,0);
$pdf->Cell(40, 2, 'Amount' ,0,1);

//----------Detail of charges header ends here ---------------------



//Emty Cell for space
$pdf->Cell(40, 5, '' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(44, 7, 'Refuse Collected Dates' ,0,0);
$pdf->SetFont('Arial','',10);
$pdf->Cell(20, 7, $prem ,0,0);
$pdf->Cell(29, 7,'GHc '. $rent .'.00' ,0,0);
$pdf->Cell(15, 7, $nolift ,0,0);
$pdf->Cell(28, 7,'GHc '. $lift. '.00' ,0,0);
$pdf->Cell(34, 7,'GHc '. $discount. '.00' ,0,0);

$pdf->Cell(50, 7,'GHc '. $mbill.'.00' ,0,1);

//---------Description details start here --------------------------
$pdf->SetFont('Arial','',10);
$pdf->Cell(30, 6, $liftdays ,0,1);
$pdf->Cell(30, 6, '' ,0,1);
$pdf->Cell(30, 6, '' ,0,1);
$pdf->Cell(30, 6, '' ,0,1);
$pdf->Cell(30, 6, '' ,0,1);

//---------Description details ends here --------------------------

//---------Description second phase start here --------------------------
//Emty Cell for space
$pdf->Cell(40, 5, '' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(131, 6, 'Amount in Words:' ,0,0);
$pdf->Cell(40, 6, 'Sub - Total:' ,0,0);

$pdf->SetFont('Arial','',10);
$pdf->Cell(51, 6,'GHc '. $mbill.'.00' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(131, 6, '' ,0,0);
$pdf->Cell(42, 6, 'Total Discount:' ,0,0);

$pdf->SetFont('Arial','',10);
$pdf->Cell(60, 6,'GHc '. $discount.'.00' ,0,1);

$pdf->SetFont('Arial','',12);
$pdf->Cell(30, 6, $nw->toWords($baldue)." ghana cedis" ,0,0);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(101, 6, '' ,0,0);
$pdf->Cell(46, 6, 'WithHolding Tax:' ,0,0);

$pdf->SetFont('Arial','',10);
$pdf->Cell(60, 6, 'GHc 0.00' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(131, 6, '' ,0,0);
$pdf->Cell(40, 6, 'Net Total:' ,0,0);

$pdf->SetFont('Arial','',10);
$pdf->Cell(60, 6, 'GHc '. $baldue.'.00' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(131, 6, '' ,0,0);
$pdf->Cell(54, 6, 'Less Deposit:' ,0,0);

$pdf->SetFont('Arial','',10);
$pdf->Cell(60, 6, '0.00' ,0,1);

//Emty Cell for space
$pdf->Cell(40, 12, '' ,0,1);

$pdf->SetFont('Arial','B',12);
$pdf->Cell(131, 6, 'Notes:' ,0,0);
$pdf->Cell(36, 6, 'Amount Due:' ,0,0);
$pdf->Cell(47, 6, 'GHc '.$baldue.'.00' ,0,1);

//Emty Cell for space
$pdf->Cell(60, 22, '' ,0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(140, 8, 'Bill Prepred By:  RMU' ,0,1);
$pdf->Cell(145, 6, 'Bill Approved By: Head of RMU:' ,0,0);

$pdf->Cell(145, 6, 'Accountant Sign' ,0,0);


$pdf->Output();


?>