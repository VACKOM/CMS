<?php
session_start();
require '../actionscript/db/connect.php';
require '../actionscript/functions/security.php';

 if(!empty($_POST)){
    
         
     
        
       $first = trim($_POST['dtp_input2']);
         $second = trim($_POST['dtp_input3']);




$con=mysqli_connect("localhost","gdatzzhm_amanAdmin","^250XLa7-IJL","gdatzzhm_amanDatabase");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
  
   $sql5="TRUNCATE client_statements";
    

if ($result5 =mysqli_query($con,$sql5))
  {
  
  if($first == "entire")
 {
 
     $sql="SELECT name  ,phone, costperland,plots,deposit, total, aid FROM client_register  ORDER BY name";

if ($result=mysqli_query($con,$sql))
  {
  // Fetch one and one row
  while ($row=mysqli_fetch_row($result))
    {
        
    
    $name = ($row[0]); 
    $contact = ($row[1]);
    $costperland = ($row[2]);
    $plots = ($row[3]);
    $deposit = ($row[4]);
    $total = ($row[5]);
   $aid = ($row[6]);
   

 $sql2="SELECT * FROM client_bills WHERE acc = '$row[6]'";

if ($result2 =mysqli_query($con,$sql2))
  {
  // Fetch one and one row
  while ($row2=mysqli_fetch_row($result2))
    {
        
         $bills = ($row2[15]);

 $sql3="SELECT * FROM client_payment WHERE acc = '$row[6]'";

if ($result3 =mysqli_query($con,$sql3))
  {
    //b1:
  
  // Fetch one and one row
  while ($row3=mysqli_fetch_row($result3))
    {
        
        $allpaid = ($row3[15]);
        
        $additionalpay = $allpaid - $deposit;
        
        $bal = $total - $allpaid;
        
        
         $dept = $bills - $allpaid;
         echo $dept;
         
          if ($dept > 0){
     goto a1;
 }else{
     $dept = 0;
    goto a1;
  }
    
     a1:

$sql4 = "INSERT INTO client_statements (aid, name,contact, costperland, plots, total, deposit, addpay, bal, baldue)
VALUES ('$aid', '$name','$contact', $costperland, $plots, $total, $deposit,$additionalpay, $bal, $dept )";


if ($result4 =mysqli_query($con,$sql4))
  {
      //echo $name;
}   

    }
  // Free result set
  mysqli_free_result($result3);
}   

    }
  // Free result set
  mysqli_free_result($result2);
 }   
    
    }
  
  // Free result set
  mysqli_free_result($result);
}

mysqli_close($con);

 }
  
 
 
 
 }
 }
 
 $_SESSION['WEB_SES'] = $first . "^" . $second;
?>

<html>
    
    <head>
          <script>

setTimeout(function()
{ 
     window.location = "http://condrasolutions.com/amanchalak_platform/reports/Statements/index.php"; 
}, 3000);
alert("Client's Statements successfully generated");

</script>
        
        
    </head>
    
    <body>
        
        <h2>Please wait ...........</h2>
    </body>
</html>
