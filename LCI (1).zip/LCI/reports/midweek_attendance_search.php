<?php
session_start();
// require '../db/connect.php';
// require '../functions/security.php';



 if(!empty($_POST)){
    
        
     
        
       $month = trim($_POST['dtp_input2']);
         $year = trim($_POST['dtp_input3']);
         
          $chapel = trim($_POST['dtp_input4']);
         
         

$selectedDate = $year ."-".$month;


$con=mysqli_connect("localhost","gdatzzhm_databaselciadmin","m{b1m!RhMGCW","gdatzzhm_databaselci");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
  
   $sql5="TRUNCATE attendance_search";
   
   
   //if the need all reports ----------------------- 
   if($chapel == "All"){

if ($result5 =mysqli_query($con,$sql5))
  {


     $sql="SELECT Date, Cid FROM weekday_attendance ORDER BY Date";

if ($result=mysqli_query($con,$sql))
  {
  // Fetch one and one row
  while ($row=mysqli_fetch_row($result))
    {
        
     $Date = ($row[0]);   
     $Cid = ($row[1]);
     
    $NewDate = substr($Date ,0,7);
    
    
    if($NewDate == $selectedDate ){
   

 

$sql4 = "INSERT INTO attendance_search (Date, Cid)
VALUES ('$Date', '$Cid')";


if ($result4 =mysqli_query($con,$sql4))
  {
      //echo $name;
}   

    }
  // Free result set
  mysqli_free_result($result3);
}   

    }
//   // Free result set
//   mysqli_free_result($result2);
//  }   
    
//     }
  
  // Free result set
  mysqli_free_result($result);
}

}else {
    if ($result5 =mysqli_query($con,$sql5))
  {


     $sql="SELECT Date, Cid FROM weekday_attendance ORDER BY Date";

if ($result=mysqli_query($con,$sql))
  {
  // Fetch one and one row
  while ($row=mysqli_fetch_row($result))
    {
        
        
     $Date = ($row[0]);   
     $Cid = ($row[1]);
     
    $NewDate = substr($Date ,0,7);
    $chapelCode2 = substr($Cid ,4,5);
        
    // echo $Mid;
    // echo $chapelCode2; 
         
    if($chapelCode2 == $chapel ){
    
    
    if($NewDate == $selectedDate ){
   

 

$sql4 = "INSERT INTO attendance_search (Date, Cid)
VALUES ('$Date', '$Cid')";


if ($result4 =mysqli_query($con,$sql4))
  {
      //echo $name;
}   

    }
  // Free result set
  mysqli_free_result($result3);
}   

    }
  }
//   // Free result set
//   mysqli_free_result($result2);
//  }   
    
//     }
  
  // Free result set
  mysqli_free_result($result);
}
    
}

mysqli_close($con);

 
 }
 
  

 
 $_SESSION['WEB_SES'] = $month . "^" . $year. "^" . $chapel;
  
 
?>

<html>
    
    <head>
          <script>

setTimeout(function()
{ 
     window.location = "http://condrasolutions.com/LCI/reports/WeekdayAttendanceReport/index.php"; 
}, 3000);
alert("Attendance Report successfully generated");

</script>
        
        
    </head>
    
    <body>
        
        <h2>Please wait ...........</h2>
    </body>
</html>
