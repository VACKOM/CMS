<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    
     <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>JSO Customer Platform</title>

         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="bootstrap/css/style4.css">
        
        
        <style>
        
        #stocklist{
            
            margin: 35px 2px;
            
        }
        
         #stockselect{
            
            margin: 35px 122px;
            
            
        }
            #col1 {
                
 background-color:#ccdeed;
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 600%;
  height:100px;
  
  
}

 #col2 {
 background-color:#ffffff;
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 600%;
  height:100px;
  
 
  /*margin-bottom: 12px;*/
}
    #col3 {
 background-color:#ccdeed;
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 600%;
  height:100px;
  
}         

 #stockLabel {
     
     font-size: 20px;
     padding: 35px;
 }
        </style>
        
    
</head>

<body>
    
    
      <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>JSO Customer Platform</h3>
                    <strong>BS</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="index.php">
                            <i class="glyphicon glyphicon-home"></i>
                            Home
                        </a>
                        
                    </li>
                    
                     <li>
                        <a href="#stockSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-book"></i>
                            Customer Control
                        </a>
                        <ul class="collapse list-unstyled" id="stockSubmenu">
                            <li><a href="../customer_types_register.php">Customer Category Register</a></li>
                            <li><a href="../customer_register.php">Customer Register</a></li>
                             <li><a href="../customer_name_search.php">Customer Search</a></li>
                            
                        </ul>
                    </li>
                    
                  
                   <li>
                        <a href="#posSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-stats"></i>
                            Point of Sales System
                        </a>
                        <ul class="collapse list-unstyled" id="posSubmenu">
                            <li><a href="../customer_payment.php">Domestic Customer Payment</a></li
                            <li><a href="../manual_customer_payment.php">Industrial Customer Payment</a></li>
                            <li><a href="#">Customer Payment Search</a></li>
                            
                        </ul>
                    </li>
                        
                    <li>
                        <a href="#bankSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-piggy-bank"></i>
                            Billing System
                        </a>
                        <ul class="collapse list-unstyled" id="bankSubmenu">
                            <li><a href="../individual_invoice_generator.php">Manual Bill Generator</a></li>
                            <li><a href="../automatic_invoice_generator.php">Automatic Bill Generator</a></li>
                            <li><a href="../manual_liftings_recorder.php">Manual Lifting Recorder</a></li>
                        </ul>
                    </li>
                    
                    <li>
                        <a href="#reportSubmenu" data-toggle="collapse" aria-expanded="false">
                            <i class="glyphicon glyphicon-hourglass"></i>
                            Report Generator
                        </a>
                        <ul class="collapse list-unstyled" id="reportSubmenu">
                            
                           <li><a href="customer_search_engine.php">Customer Search Engine</a></li>
                            <li><a href="#">Customer Statements Generator</a></li>
                            <li><a href="../reports/expected_revenue_report.php">Expected Revenue Report</a></li>
                            <li><a href="../reports/revenue_generation_report.php">Revenue Generation Report</a></li>
                            
                        </ul>
                    </li>
                   
                </ul>

                
            </nav>

            <!-- Page Content Holder -->
            <div id="content">

                <nav class="navbar navbar-default">
                    <div class="container-fluid">

                        <div class="navbar-header">
                            <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn">
                                <i class="glyphicon glyphicon-align-left"></i>
                                <span>Toggle Sidebar</span>
                            </button>
                        </div>

                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            
                        </div>
                    </div>
                </nav>
                
                
                <h2>Customer Search Engine</h2>
                <br>
                <hr>
                 <div class="alert alert-info fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
    <strong>Note!</strong> Select the date to view its sales report......
</div>
<br>
                
               <div class="container">
    
        
         <form class="form-horizontal" name="form" action="CustomerSearch/index.php" method="post">
             
              <div class="form-group">
      <label class="control-label col-sm-2" for="sub">Search:</label>
      <div class="col-sm-10">  
      
       
        
            <select id="sub" class="form-control"  placeholder="Enter Stock name" name="sub"  onchange="document.getElementById('dtp_input2').value=this.options[this.selectedIndex].value; myFunction(); changeIt()">
                <option value="">Select Customers's search criteria</option>
                 <option value="all">Customer Main List</option>
                <!--<option value="">Customer Type</option>-->
                <option value="subarea">Sub Metro Area</option>
                <option value="area">Electoral Area</option>
                <option value="binca">Bin Capacity</option>
                <option value="billt">Billing Type</option>
                <option value="class">Classification</option>
                
            </select>
            
             <div class="form-group">
                 <div class="col-sm-12" id="my_div">  
                 
                 </div>
       
      
      </div>
    </div>
       
          
			<!--<div class="form-group">-->
			    
   <!--             <label for="dtp_input2" class="col-md-2 control-label">Date Picking</label>-->
   <!--             <div class="input-group date form_date col-md-5" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">-->
   <!--                 <input class="form-control" size="16" type="text" value="" readonly>-->
   <!--                 <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>-->
			<!--		<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>-->
					
					
   <!--             </div>-->
   <!--             </div>-->
                
                
                <div class="form-group">
				<input type="hidden" id="dtp_input2" name="dtp_input2" value="" /><br/>
				
					<input type="hidden" id="dtp_input3" name="dtp_input3" value="" /><br/>
            </div>
		
        
        
         <br>
    <div class="form-group">        
      <div class="col-sm-offset-8 col-sm-10">
      
        
        <input type="button" class="btn btn-primary" value="Reset" onclick="location.reload();" />
       
        <button type="submit" class="btn btn-primary">Search for Customer Details
        
        
        </button>
      </div>
    </div>
    </form>
</div>
        </div>



<!--<script type="text/javascript" src="jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>-->
<!--<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>-->
<!--<script type="text/javascript" src="bootstrap/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>-->
<!--<script type="text/javascript" src="bootstrap/js/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>-->

<script type="text/javascript">
//     $('.form_datetime').datetimepicker({
//         //language:  'fr',
//         weekStart: 1,
//         todayBtn:  1,
// 		autoclose: 1,
// 		todayHighlight: 1,
// 		startView: 2,
// 		forceParse: 0,
//         showMeridian: 1
//     });
// 	$('.form_date').datetimepicker({
//         language:  'en',
//         weekStart: 1,
//         todayBtn:  1,
// 		autoclose: 1,
// 		todayHighlight: 1,
// 		startView: 2,
// 		minView: 2,
// 		forceParse: 0
//     });
// 	$('.form_time').datetimepicker({
//         language:  'en',
//         weekStart: 1,
//         todayBtn:  1,
// 		autoclose: 1,
// 		todayHighlight: 1,
// 		startView: 1,
// 		minView: 0,
// 		maxView: 1,
// 		forceParse: 0
//     });
    
    function myFunction() {
        //alert("yesssssssss");
        
         
    };
    
    function changeIt()
{
    var boxs = 0;
    
    if(document.getElementById("dtp_input2").value == "Customer Type"){

    
    var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"



var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Customer Type', 'Select Customer Type');
select.options[select.options.length] = new Option('Industrial', 'Industrial');
select.options[select.options.length] = new Option('Domestic', 'Domestic');
select.options[select.options.length] = new Option('Commercial', 'Commercial');

document.getElementById("sub").disabled = true;

// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"

}

// ----------------------- end of Customer Type ----------------------------

// ----------------------- begining of Main List -------------------

else if(document.getElementById("dtp_input2").value == "all"){
    
    document.getElementById("dtp_input3").value = "all";
//      var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"



// var select = document.getElementById("mytext");
// select.options[select.options.length] = new Option('Select Sub Metro Area', 'Select Sub Metro Area');
// select.options[select.options.length] = new Option('Okaikwei South', 'Okaikwei South');
// select.options[select.options.length] = new Option('Okaikwei North', 'Okaikwei North');



// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"

}

// ----------------------- end of Customer Type ----------------------------

// ----------------------- begining of Sub Metro -------------------

else if(document.getElementById("dtp_input2").value == "subarea"){
    
     var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"



var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Sub Metro Area', 'Select Sub Metro Area');
select.options[select.options.length] = new Option('Okaikwei South', 'Okaikwei South');
select.options[select.options.length] = new Option('Okaikwei North', 'Okaikwei North');

document.getElementById("sub").disabled = true;

// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"

}

// ----------------------- end of Customer Type ----------------------------

// ----------------------- begining of Sub Metro -------------------

else if(document.getElementById("dtp_input2").value == "area"){

    
    var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"

var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Electoral Area', 'Select Electoral Area');
select.options[select.options.length] = new Option('Kaneshie 1', 'Kaneshie 1');
select.options[select.options.length] = new Option('Kaneshie 2', 'Kaneshie 2');
select.options[select.options.length] = new Option('Bubii', 'Bubii');
select.options[select.options.length] = new Option('Bubuashie', 'Bubuashie');
select.options[select.options.length] = new Option('Kanstean', 'Kanstean');
select.options[select.options.length] = new Option('North Industrial Area', 'North Industrial Area');
select.options[select.options.length] = new Option('South Industrial Area', 'South Industrial Area');
select.options[select.options.length] = new Option('Avenor Accra', 'Avenor Accra');
select.options[select.options.length] = new Option('Mukose', 'Mukose');
select.options[select.options.length] = new Option('Gontein', 'Gontein');

// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"
document.getElementById("sub").disabled = true;

}

// ----------------------- end of Customer Type ----------------------------

// ----------------------- begining of bin capacity -------------------

else if(document.getElementById("dtp_input2").value == "binca"){

    
    var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"

var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Bin Capacity', 'Select Bin Capacity');
select.options[select.options.length] = new Option('60', '60');
select.options[select.options.length] = new Option('120', '120');
select.options[select.options.length] = new Option('240', '240');
select.options[select.options.length] = new Option('360', '360');
select.options[select.options.length] = new Option('1100', '1100');
select.options[select.options.length] = new Option('3600', '3600');
select.options[select.options.length] = new Option('10,000', '10,000');
select.options[select.options.length] = new Option('12,000', '12,000');
select.options[select.options.length] = new Option('23,000', '23,000');

// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"
document.getElementById("sub").disabled = true;

}

// ----------------------- begining of Sub Metro -------------------

// ----------------------- begining of bin capacity -------------------

else if(document.getElementById("dtp_input2").value == "class"){

    
    var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"

var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Customer Classification', 'Select Bin Capacity');
select.options[select.options.length] = new Option('House', 'House');
select.options[select.options.length] = new Option('Institution', 'Institution');
select.options[select.options.length] = new Option('Commercial', 'Commercial');
select.options[select.options.length] = new Option('Hotel/Restaurant', 'Hotel/Restaurant');
select.options[select.options.length] = new Option('Factory/Industry', 'Factory/Industry');

document.getElementById("sub").disabled = true;
// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"

}

// ----------------------- begining of Sub Metro -------------------




else if(document.getElementById("dtp_input2").value == "billt"){

    
    var i = 1;
my_div.innerHTML = my_div.innerHTML +"<br><select class='form-control' id ='mytext' onchange='mySelect()' name='mytext'+ i>"

var select = document.getElementById("mytext");
select.options[select.options.length] = new Option('Select Billing Type', 'Select Billing Type');
select.options[select.options.length] = new Option('Manual', 'Manual');
select.options[select.options.length] = new Option('Automatic', 'Automatic');
select.options[select.options.length] = new Option('Door To Door', 'Door To Door');
document.getElementById("sub").disabled = true;

// var i = 1;
// my_div.innerHTML = my_div.innerHTML +"<br><input type='text' class='form-control' name='mytext'+ i>"

}

// ----------------------- end of Customer Type ----------------------------
}



    function mySelect() {
        document.getElementById("dtp_input3").value = document.getElementById("mytext").value;
        
         
    };
    
    function reset(){
    window.location.reload(true);
}
    
</script>





        <!-- jQuery CDN -->
         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
         </script>
    </body>
    

</html>
