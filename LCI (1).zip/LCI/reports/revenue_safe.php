<?php
session_start();
// //error_reporting(0);
require '../actionscript/db/connect.php';



    // select suppliers code ..................................
    
  if(!empty($_POST)){
    
         
         
         
          $records4 = array();

if($results4 = mysqli_query($db,"TRUNCATE expected_revenue")){
    
    
    



        
      $first = trim($_POST['dtp_input2']);
         $second = trim($_POST['dtp_input3']);
         
        //  echo $first;
        //  echo $second;
         
         
         
         if($first == "all"){
             
             $records = array();

if($results = mysqli_query($db,"SELECT * FROM client_register Where payoption = 'Installment'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
}

if(! count($records)){
    echo 'No Match Records Foundkkkkkkk...';
}else{
         
}
//}

foreach($records as $r){
    
        $pay = ($r->pay);
        $qty = 1;
        $total = $pay * $qty;
        $area = "-";
        
        //echo $pay;
       
        $insert = $db->prepare("INSERT INTO expected_revenue (pay, qty,total) VALUES (?,?,?)");
            $insert->bind_param('iii', $pay,$qty,$total);
                




            
            if($insert->execute ()){
                
                
                
                
                
                
                
               // echo "done";
            }
        
        
        //  echo ($qty);
        //  echo ($sell);
        
        
}
             
             
         }else{
       

$records = array();

if($results = mysqli_query($db,"SELECT pay FROM client_register where payoption = 'Installment' AND $first = '$second'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
}

if(! count($records)){
    echo 'No Match Records Foundhhhhhh...';
}else{
         
}
//}

foreach($records as $r){
    
         $pay = ($r->pay);
        $qty = 1;
        $total = $pay * $qty;
        $area = "-";
        
        //echo $pay;
       
        $insert = $db->prepare("INSERT INTO expected_revenue (pay, qty,total) VALUES (?,?,?)");
            $insert->bind_param('iii', $pay,$qty,$total);
                




            
            if($insert->execute ()){
                
                 
                
                
                
               // echo "done";
            }
        
        
        //  echo ($qty);
        //  echo ($sell);
        
        
        
       
}
}
        
   } 
  }
  
    $_SESSION['WEB_SES'] = $first . "^" . $second;
       
        
   
    
?>
         
         <script>

setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/amanchalak_platform/reports/ExpectedRevenue/index.php"; 
}, 500);
alert("New Report generated");

</script>
                
  <?php            

?>


<!--<html>-->
    
<!--    <head>-->
<!--          <script>-->

<!--setTimeout(function()-->
<!--{ -->
<!--     window.location = "https://condrasolutions.com/jso_platform/reports/CustomerSearch"; -->
<!--}, 2000);-->
<!--alert("Generating Report ........");-->

<!--</script>-->
        
        
<!--    </head>-->
    
<!--    <body>-->
        
<!--        <h2>Please wait ...........</h2>-->
<!--    </body>-->
<!--</html>-->


