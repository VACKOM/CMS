<?php 

session_start();

$Array = explode("^", $_SESSION['WEB_SES']);


 $month = $Array[0];
 $year = $Array[1];
  $Name = $Array[2];
  
  echo $month;
 
 
 if($month == "01")
 {
     $newmonth = "January";
 }
 else if($month == "02")
 {
     $newmonth = "February";
 }
 
 else if($month == "03")
 {
     $newmonth = "March";
 }

else if($month == "04")
 {
     $newmonth ="April";
 }
 
 else if($month == "05")
 {
     $newmonth = "May";
 }
 
 else if($month == "06")
 {
     $newmonth ="June";
 }

else if($month == "07")
 {
     $newmonth = "July";
 }
 
 else if($month == "08")
 {
     $newmonth = "August";
 }
 
 else if($month == "09")
 {
     $newmonth = "September";
 }
 
 else if($month == "10")
 {
     $newmonth = "October";
 }
 
 else if($month == "11")
 {
     $newmonth = "November";
 }
 
 else if($month == "12")
 {
     $newmonth = "December";
 }

 
 if($Name == "All")
 {
     $chapel = "All Chapels";
 }
 
 else if($Name == "ACTS/")
 {
     $chapel = "Acts Chapel";
 }
 
 else if($Name == "COLOS")
 {
     $chapel = "Colossians Chapel";
 }
 
 else if($Name == "CORIN")
 {
     $chapel = "Corinthians Chapel";
 }
 
 else if($Name == "EXODU")
 {
     $chapel = "Exodus Chapel";
 }
 
 else if($Name == "GALAT")
 {
     $chapel = "Galatians Chapel";
 }
 
 else if($Name == "GENES")
 {
     $chapel = "Genesis Chapel";
 }
 else if($Name == "HEBRE")
 {
     $chapel = "Hebrews Chapel";
 }
 
 else if($Name == "JAMES")
 {
     $chapel = "James Chapel";
 }
 
 else if($Name == "JOEL/")
 {
     $chapel = "Joel Chapel";
 }
  else if($Name == "JOHN/")
 {
     $chapel = "John Chapel";
 }       
 else if($Name == "JOSHU")
 {
     $chapel = "Joshua Chapel";
 }
 
 else if($Name == "JUDE/")
 {
     $chapel = "Jude Chapel";
 }
 
 else if($Name == "LUKE/")
 {
     $chapel = "Luke Chapel";
 }
 else if($Name == "MARK/")
 {
     $chapel = "Mark Chapel";
 }
 else if($Name == "MATTH")
 {
     $chapel = "Matthew Chapel";
 }
     else if($Name == "NEHEM")
 {
     $chapel = "Nehemiah Chapel";
 }          
 else if($Name == "PHILE")
 {
     $chapel = "Philemon Chapel";
 }
 else if($Name == "PHILL")
 {
     $chapel = "Phillipians Chapel";
 }
 else if($Name == "PETER")
 {
     $chapel = "Peter Chapel";
 }
 else if($Name == "ROMAN")
 {
     $chapel = "Romans Chapel";
 }
 else if($Name == "SAMUE")
 {
     $chapel = "Samuel Chapel";
 }
 else if($Name == "TIMOT")
 {
     $chapel = "Tinothy Chapel";
 }
                
            
 
 
    
    use \koolreport\widgets\koolphp\Table;
    use \koolreport\widgets\google\BarChart;
?>

<html>
    <head>
         <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        
         <title>Attendance Report</title>
         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        
        <style>
        
        #title {
 background-color:#ccdeed;
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 32px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}
            
            body {
                      background: rgb(204,204,204); 
                    }
                    page {
                     /*background: white;*/
                      /*display: block;*/
                      margin: 0 auto;
                      margin-bottom: 0.5cm;
                      /*box-shadow: 0 0 0.5cm rgba(0,0,0,0.5);*/
                    }
                    page[size="A4"] {  
                      width: 21cm;
                      height: 29.7cm; 
                      padding-top: 50px;
                        padding-right: 80px;
                        padding-bottom: 50px;
                        padding-left: 80px;
                      
                    }
                    page[size="A4"][layout="portrait"] {
                      width: 29.7cm;
                      height: 21cm;  
                       padding-top: 50px;
                        padding-right: 80px;
                        padding-bottom: 50px;
                        padding-left: 80px;
                    }
                    page[size="A3"] {
                      width: 29.7cm;
                      height: 42cm;
                    }
                    page[size="A3"][layout="portrait"] {
                      width: 42cm;
                      height: 29.7cm;  
                    }
                    page[size="A5"] {
                      width: 14.8cm;
                      height: 21cm;
                    }
                    page[size="A5"][layout="portrait"] {
                      width: 21cm;
                      height: 14.8cm;  
                    }
                    @media print {
                      body, page {
                        margin: 0;
                        box-shadow: 0;
                      }
                    }
            
            
             
        .cssHeader
        {
            background-color:#e9ffe8;
        }
        .cssItem
        {
            background-color:#fdffe8;
        }
       
        </style>
        
        <body>
        
    </head>
    <body>
        
        <page size="A4" layout="portrait">
        <!--<page size="A4"></page>-->
<!--<page size="A4"></page>-->

<!--<page size="A5"></page>-->
<!--<page size="A5" layout="portrait"></page>-->
<!--<page size="A3"></page>-->
<!--<page size="A3" layout="portrait"></page>-->
        
       

        
            <div class="text-center">

        <h1 id="title">Attendance Report</h1>
        <h3><?php echo $chapel ?> Sunday Services</h3>
        <h3>Result By <?php echo $newmonth." ". $year ?></h3>
        <br>
        
        <button type="submit" id ="stockselect" onclick="goBack()" class="btn btn-primary">Click to Attendance Report Engine</button>
        <br>
 <br>
  <br>
<?php
    BarChart::create(array(
        "dataStore"=>$this->dataStore('attendance_search'),
        
        "paging"=>array(
        "pageSize"=>8,
    ),
        
        "width"=>"100%",
        "height"=>"500px",
        "showFooter"=>"bottom",
        "columns"=>array(
            "Date"=>array(
                "label"=>"Service Dates"
            ),
            "Cid"=>array(
                "type"=>"number",
                "label"=>"Total Attendance",
                
                 "footer"=>"sum"
            )
             
        ),
        
       
        
        "options"=>array(
            "title"=>"Attendance"
            
        )
        
       
    ));
?>
<?php

Table::create(array(
    "dataStore"=>$this->dataStore('attendance_search'),
    //  "paging"=>array(
    //     "pageSize"=>9,
        
    // ),
        "showFooter"=>"top",
        "columns"=>array(
            
             "Date"=>array(
                "label"=>"Dates",
                "footer"=>"count",
                "footerText"=>"No of Weeks: @value",
                "cssStyle"=>"text-align:left"
            ),
            
            
            "Cid"=>array(
                "label"=>"NO"
               
            )
            
           
           
        ),
    "cssClass"=>array(
        "table"=>"table table-hover table-bordered",
        "th"=>"cssHeader",
            "tr"=>"cssItem"
        
    )
));
?>

 </div>
        

<script>
function goBack() {
       window.location = "http://condrasolutions.com/LCI/admin_attendance_search.php"; 

   
}
</script>
        
        </page>
    </body>
</html>
