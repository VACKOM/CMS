<?php
 session_start();

 require_once "../koolreport/autoload.php";
use \koolreport\processes\Group;
use \koolreport\processes\Sort;
use \koolreport\processes\Limit;
use \koolreport\processes\AggregatedColumn;

        
    
class Attendance extends \koolreport\KoolReport
{
    public function settings()
    {
        return array(
            "dataSources"=>array(
                "attendance_search"=>array(
                    "connectionString"=>"mysql:host=localhost;dbname=gdatzzhm_databaselci",
                    "username"=>"gdatzzhm_databaselciadmin",
                    "password"=>"m{b1m!RhMGCW",
                    "charset"=>"utf8"
                )
            )
        );
    }

    public function setup()
    {
         
       
             
              $this->src('attendance_search')
        ->query("SELECT Date, Cid FROM attendance_search")
        
        
        
        ->pipe(new Group(array(
             "by"=>"Date",
             "count"=>"Cid",
        )))
        
       
         
        ->pipe(new Sort(array(
            "count"=>"desc"
        )))
        
       
          
        // ->pipe(new Limit(array(10)))
        ->pipe($this->dataStore('attendance_search'));
             
       
        
       
}

}

				