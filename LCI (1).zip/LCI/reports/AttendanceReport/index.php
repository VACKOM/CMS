<?php
 require_once "Attendance.php";
 


$Attendance = new Attendance;
$Attendance->run()->render();



?>
<!DOCTYPE >
<html>
    <head>
        <title>Customer List</title>
        <link rel="stylesheet" href="../../../assets/bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="../../../assets/bootstrap/css/bootstrap.theme.min.css" />
        <link rel="stylesheet" href="../../../assets/css/example.css" />
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCj8ahVQXoy8wHCAwoRWsUjPVmR5N3Qgko"
  type="text/javascript"></script>
    </head>
    <body>      
        <div class="container box-container">
            
        </div>
    </body>
</html>				