<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';


?>
<!DOCTYPE html>
<html>
<head>
   

    <title> CMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes" />
        
 <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    
   
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>  
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    <body>
    <div data-role="page" id="Home" data-theme="d">        

        <div data-role="header" data-position="fixed">
            <h1>Send SMS</h1>
            <div data-role="navbar">
         <ul>
         <li><a href= "schedules.php" data-ajax="false">Daily Schedules</a></li>
         </ul>
         </div> 
        </div>
    <div data-role="content">
   <form action="receiverschedulesms.php?&finalactivity=<?php echo $_GET['finalactivity'] ?>" method="post">

<label>SMS: Send SMS Messages</label>

<label><h4>Phone Number</h4></label>
<input type="text" name="phone" placeholder="Phone Number......"  value = <?php echo $_GET['action'] ?> disabled  />

<label><h4>Name</h4></label>
<input type="text" name="name"   value = <?php echo $_GET['firstname'] ?> <?php echo $_GET['lastname'] ?>  disabled  />
<br>
<input type="text" name="senderid" placeholder="Type in the Sender Name...." maxlength="11" />

<label><h4>Message</h4></label>
<textarea type="text" name="message" placeholder="Type in your message here....." maxlength = "160" height="500"></textarea>


<br>
<input type = "hidden" name="phonenumber" id="phonenumber"  value = <?php echo $_GET['action'] ?>></input>

<input type="submit" value="Send"/>

</form>

<?php
$search = $_GET['action'];
$CFName = $_GET['firstname'];
$CLName = $_GET['lastname'];
$finalactivity = $_GET['finalactivity'];

?>


</div>
</div>
  <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>
</body>
</html>
