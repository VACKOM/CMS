<html>
<head>
  <title> CMS</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
  <meta name="apple-mobile-web-app-capable" content="yes" />
      
 <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
  
   
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>  
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
  <link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    <body>
    
<div data-role="page" id="Home" data-theme="d">        

        <div data-role="header" data-position="fixed">
            <h1>News Categories</h1>
        </div>

        <div data-role="content">
    
            
            <?php
        try
                {
                    include('db/connString.php');
                    
                    $sqlQuery ="SELECT * FROM events";
                    $result = mysql_query($sqlQuery, $mysql_connStr);                    
                   
                    print("<ol data-role=\"listview\" data-filter=\"true\" data-inset=\"true\">");
                        while($row = mysql_fetch_array($result))
                        {                      
                            print("<li data-ibm-jquery-contact=\"".$row['EHead']."\">");
                            print("<a data-rel=\"page\" data-transition=\"pop\"href=\"UpdateRec.php?action=".$row['EHead']."\">");                           
                            print("".$row['EHead']."<br/>");
                            print("</a>");
                            print("</li>\n");                            
                        }                        
                    print("</ol>");                         
                }
                catch(Exception $e)
                {
                    echo $e->getMessage();
                }

                mysql_close($mysql_connStr);
            ?>
               
        </div>
        <div data-role="footer" data-position="fixed">

            <h1>Contact &copy;</h1>
        </div>

    </div>
            
    </body>
    
</html>