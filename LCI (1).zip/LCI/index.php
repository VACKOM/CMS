<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
 
sec_session_start();
 
if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
     
}
?>
<!DOCTYPE html>
<html>

    
    
    <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
    <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
       <script>
       
       
      
       </script>
</head>
    
    
    
    
    <body>
        <?php
        if (isset($_GET['error'])) {
            echo '<p class="error">Error Logging In!</p>';
        }
        ?> 
        
         <!-- Page Content Holder -->
          <div data-role="page" id="login" data-theme="d" >
    
            <div data-role="header" data-theme="d" >
                
                <div class="center-image"><h1>LCI</h1></div>
                 <div class="center-image"><h2>Chapel Management System</h2>
                
                     <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
                
                
                </div>
                
                <br>
                
                 
    
 <div data-role="content" data-theme="d">
        
        <form action="includes/process_login.php" method="post" name="login_form"> 
        
<div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10"> 
       <input class="form-control" id="email" type="email" name="email" value="" >
      </div>
    </div>
        
<div class="form-group">
      <label class="control-label col-sm-2" for="password">Password:</label>
      <div class="col-sm-10"> 
       <input class="form-control" id="password" type="password" name="password" value="" >
      </div>
    </div>        
           
 <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary" onclick="formhash(this.form, this.form.password);" >Login</button>
      </div>
    </div>
           
        </form>
        
        </div>
 </div>
<?php
        if (login_check($mysqli) == true) {
                        echo '<p>Currently logged ' . $logged . ' as ' . htmlentities($_SESSION['username']) . ' Chapel'.'.</p>';
 
            echo '<p>Do you want to change user? <a href="includes/logout.php">Log out</a>.</p>';
        } else {
                        
                        header('Location: ../index.php');
                        echo '<p>Currently logged ' . $logged . '.</p>';
                        // echo "<p>If you don't have a login, please <a href='register.php'>register</a></p>";
                        echo "<p>Enter Chapel Email Address & Password to Login</p>";
                }
?>    

 </div>
    
            <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>   

    </body>
</html>