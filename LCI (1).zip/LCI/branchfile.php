<!DOCTYPE HTIML>
<?php
//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';


if(!empty($_POST)){
    
        
        $Bco = trim($_POST['Bco']);
        $BName = trim($_POST['BName']);
        $BLoc = trim($_POST['BLoc']);
        $BMan= trim($_POST['BMan']);
        $BNo = trim($_POST['BNo']);
        $BReg = trim($_POST['BReg']);
     $breg = new DateTime($BReg);
         $breg = $breg->format('d-m-Y'); // 31-07-2012
    
        
        if(!empty($Bco)&& !empty($BName) && !empty($BLoc) && !empty($BMan) && !empty($BNo)&& !empty($BReg)){
            $insert = $db->prepare("INSERT INTO branch (Bco, BName, BLoc, BMan, BNo, BReg) VALUES (?,?,?,?,?,?)");
            $insert->bind_param('ssssss', $Bco,$BName, $BLoc,$BMan,$BNo, $BReg);
            
            if($insert->execute ()){
           
            header('Location: index.php');
            }
            
        }
    }

?>



<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
   
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    <body>
<div data-role="page" id="schedule" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Address Organizer</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
    
        
        
        
        <div data-role="content">

        <ol data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Sub Menu</li>
            <li><a href= "#NewCon">Enter New Branch</a></li>
             <li><a href= "#BList">Branch List</a></li>
            <li><a href= "">Edit Existing Branch</a></li>      
            <li><a href= "">Delete Existing Branch</a></li>
            
        </ol>
    
        </div>
    
        
    
        
        
       
  
    
  </div>
        
         <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
        <!--  Page for New Branch Entry-->
        
        
<div data-role="page" id="NewCon" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>New Branch Entry Form</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="" method="POST" data-ajax = "false">
                <h4> Enter Contact Details .</h4>
                <br>
                 
                 <label for="bno">Branch Code:</label>   
                <input type="text" id ="Bco" name="Bco" value =""  
                   placeholder="Enter Branch Number.....">
                    <br>
                 
                 <label for="bname">Branch Name:</label>
                 <input type="text" id ="BName" name="BName" value =""  
                   placeholder="Enter Branch Name.....">
                    <br>
                 
                 <label for="bloc">Branch Location:</label>
                 <input type="text" id ="BLoc" name="BLoc" value =""  
                   placeholder="Enter Branch Location.....">
                    <br>
                 
                 <label for="bman">Branch Manager:</label>
                 <input type="text" id ="BMan" name="BMan" value =""  
                   placeholder="Enter Manager's Name.....">
                    <br>
                 
                 <label for="bcont">Branch Contact Number:</label>
                 <input type="text" id ="BNo" name="BNo" value =""  
                   placeholder="Enter Contact Number.....">
                    <br>
                 
                 <label for="breg">Date of Registration:</label>
                 <input type="date" id ="BReg" name="BReg" value =""  
                   placeholder="Select Registration Date.....">
                    <br> 
                 
                    <br>
                 
                 
                 
                 
                <input type="submit" id ="submit" value="Save" >
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>
        
        
        
        <!--  Page for Branch List-->
        
        
<div data-role="page" id="BList" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>All Branches</h4>
        
     </div>
    
          <div data-role="content">
    
             
 <?php
                 
 $records = array();

if($results = mysqli_query($db,"SELECT * FROM branch ")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}
        
        
    
     foreach($records as $r){
         
         
         ?>
        
            
            
                            
          <select name="select" id ="choice">
              <?php ($count++);?> 
<option value="Option 1"> <?php echo ($r->BName);?></option>
<option value="Option 2">Branch Code: <?php echo ($r->Bco);?></option>
<option value="Option 3">Branch Location: <?php echo ($r->BLoc);?></option>
<option value="Option 4">Contact Number: <?php echo ($r->BNo);?></option>
 <option value="Option 5">Manager in Charge: <?php echo ($r->BMan);?></option>             
</select>
              <?php
         
              }
?>
                
              
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>
        
        
        <!--  Page for New Branch Edit-->
        
        
        <div data-role="page" id="CustName" data-theme="d">
     <div data-role="header" data-theme="d">
         <h4>Name Search</h4>
        
     </div>
    
          <div data-role="content">
    
             <form action="Authentication.php" method="POST" data-ajax = "false">
                <h4> Enter Customer Name for Search</h4>
                <br>
                    
                <input type="text" id ="CNSearch" name="CNSearch" value =""  
                   placeholder="Customer Name.....">
                    <br>
                 
                <input type="submit" id ="submit" value="Search" onClick="history.go(0)">
                   
              </form>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2014</h2>
          </div>

        
    
  </div>

    </body>
</html>