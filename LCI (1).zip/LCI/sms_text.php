<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
require 'db/connect.php';
require 'functions/security.php';


    
 echo "begin" ;       


$records = array();

if($results = mysqli_query($db,"SELECT * FROM membersfile")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
         
}
//}

foreach($records as $r){
    
        
         $key="0b780da0f5b5ef17808c";
         $phone = ($r->CContact);
         echo $phone;
       
         $sender_id="Rev Romeo";
         
         $message = ("There WILL BE NO SERVICE AT THE CHURCH PREMISE tomorrow. Kindly hook to a Livestream service from The Qadesh page on Facebook between 10am-11:30am. Blessings");
        
   

$url="https://apps.mnotify.net/smsapi?key=$key&to=$phone&msg=$message&sender_id=$sender_id";

$result=file_get_contents($url); //call url and store result;

switch($result){
    case "1000":
	echo "Message sent";
	break;
    case "1002":
	echo "Message not sent";
	break;
    case "1003":
	echo "You don't have enough balances";
	break;
    case "1004":
	echo "Invalid API Key";
	break;
    case "1005":
	echo "Phone number not valid";
	break;
    case "1006":
	echo "Invalid Sender ID";
	break;
    case "1008":
	echo "Empty message";
	break;
}

        
        
       
}

        
  
        
        



// $con=mysqli_connect("localhost","gdatzzhm_databaselciadmin","m{b1m!RhMGCW","gdatzzhm_databaselci");
// // Check connection
// if (mysqli_connect_errno())
//   {
//   echo "Failed to connect to MySQL: " . mysqli_connect_error();
//   }

// $sql="SELECT CContact,Cid FROM membersfile WHERE CBranch = 'test'";

// if ($result=mysqli_query($con,$sql))
//   {
//   // Fetch one and one row
//   while ($row=mysqli_fetch_row($result))
//     {
      
    
        
        


  
// }   



    
    
    
  
//   // Free result set
//   mysqli_free_result($result);
// }

// mysqli_close($con);

 
?>

<html>
    
    <head>
          <script>

setTimeout(function()
{ 
     window.location = "http://jsogroupsolutions.com/jso_platform/automatic_invoice_generator.php"; 
}, 3000);
alert("Monthly Bill successfully generated");

</script>
        
        
    </head>
    
    <body>
        
        <h2>Please wait ...........</h2>
    </body>
</html>
