<!DOCTYPE HTIML>



<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />

    	 <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    
	
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>
    <body>


<div data-role="page" id="email/sms" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Email / SMS Server</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     <div data-role="content">

      <ul data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Select</li>
            <li><a href= "#sms">Send SMS</a></li>
            <li><a href= "#email">Send Email</a></li>      
           
            
        
        </ul>

     </div>
</div>


<div data-role="page" id="sms" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Send SMS</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     <div data-role="content">
<form action="receiver.php" method="post">

<label>SMS: Send SMS Messages</label>
<input type="text" name="senderid" placeholder="Type in the Sender Name...." maxlength="11" />
<br>
<input type="text" name="phonenumber" placeholder="Phone Number......" />


<label><h4>Message</h4></label>
<textarea type="text" name="message" placeholder="Type in your message here....." maxlength = "160" height="500"></textarea>


<br>

<input type="submit" value="Send"/>

</form>
        </div>
   
    
  </div>


  <div data-role="page" id="email" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Send Email</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     <div data-role="content">
<form action="receiver.php" method="post">
<label>Email: Send Email</label>

<input type="text" name="senderid" placeholder="Type in the Sender Name...." maxlength="11" />
<br>
<input type="text" name="emailaddress" placeholder="Enter Email Address......" maxlength="20"/>


<label><h4>Message</h4></label>
<textarea type="text" name="message" placeholder="Type in your message here....." maxlength = "160" height="500"></textarea>


<br>

<input type="submit" value="Send"/>

</form>
        </div>
   
    
  </div>

    </body>
</html>