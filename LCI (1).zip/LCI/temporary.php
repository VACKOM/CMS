<?php
if(! count($records)){
    //echo 'No Match Records Found...';
}else{
   
?>
        
 
    
           
        
         
          
         <?php
    
     foreach($records as $r){
         
         
         ?>  
          
        
         <label for= "head"><i><center><h2><?php echo ($r->EHead);?></h2></center></i></label>
         <br>
         <label><b>Description:</b></label>
         
         <label for= "head"><i><?php echo ($r->EDes);?></i></label>
    <form id="hidden">
       <input type = "hidden" id = "test" name = "test">
    </form>
     
         <hr>
         <br>
         
         <label><b>Organisation:</b></label>
         
         <label for= "or"><i><?php echo ($r->EOrg);?></i></label>
        
         <hr>
         <br>
         
         <label><b>Location:</b></label>
         
         <label for= "loc"><i><?php echo ($r->ELoc);?></i></label>
         <hr>
         
         <br>
         <label><b>Contact Number:</b></label>
         
         <label for= "con"><i><?php echo ($r->ECont);?></i></label>
        
         <hr>
         <br>
         
         
           <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="Estart"><b>Starting Date:</b></label>
                       
          <label for= "start"><i><?php echo ($r->EStart);?></i></label>
                      
         <br>   
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
         <br>   
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime1"><b>Starting Time:</b></label>
                       
          <label for= "time1"><i><?php echo ($r->ETime1);?></i></label>
        

      </div>
      
    </div>
         
         <hr>
         <br>
         
           <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="end"><b>Ending Date:</b></label>
                       
          <label for= "endi"><i><?php echo ($r->EEnd);?></i></label>
                      
         <br>   
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
         <br>   
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime2"><b>Ending Time:</b></label>
                       
          <label for= "time2"><i><?php echo ($r->ETime2);?></i></label>
        

      </div>
      
    </div>
         
         <hr>
         <hr>
         <br>
         
         <input type="submit" id ="create" value="Attended">  
    
    </div>
         
         <?php
         
        
     }
}
?>
        
     
  
    
 
        