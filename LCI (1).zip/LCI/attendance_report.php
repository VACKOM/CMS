<?php

require 'db/connect.php';
require 'functions/security.php';
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
 
if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
  header('Location: index.php');
}

$Chapel =$_SESSION['username'];
echo $Chapel;
$Count = 0;

$SelectedDate = $_GET['action'];

$counting = '0';
$chapelCount =0;
session_start();
?>



<!DOCTYPE HTML>

<html>
<head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
    
   

 <div data-role="page" id="John" data-theme="d">
     <div data-role="header" data-theme="d">
     <h4>Sunday Attendance</h4>
     <div data-role="navbar">
         <ul>
         <li><a href= "javascript:history.back()" >Service Dates</a></li>
         </ul>
         </div>
        
     </div>
    
          <div data-role="content">
              
    <?php
    // Searching for atendance again --------------
    
   $records4 = array();

if($results4 = mysqli_query($db,"SELECT * FROM sunday_attendance")){
    
    if($results4->num_rows){
        while($row4 = $results4->fetch_object()){
            $records4[]=$row4;
        }
        $results4->free();
        
    }

}

if(! count($records4)){
    echo 'No Match Records Found...';
}else{
    
   
}


if($Chapel == "Exodus"){
  $myChapel = "EXODU";
}

else if($Chapel == "John"){
   $myChapel = "JOHN/";
}

else if($Chapel == "Romans"){
   $myChapel = "ROMAN";
}
  
else if($Chapel == "Joel"){
   $myChapel = "JOEL/";
}

else if($Chapel == "Hebrews"){
   $myChapel = "HEBRE";
}

else if($Chapel == "Peter"){
   $myChapel = "PETER";
}

else if($Chapel == "Corinthians"){
   $myChapel = "CORIN";
}

else if($Chapel == "Jude"){
   $myChapel = "JUDE/";
}

else if($Chapel == "Genesis"){
   $myChapel = "GENES";
}

else if($Chapel == "Philemon"){
   $myChapel = "PHILE";
}

else if($Chapel == "Samuel"){
   $myChapel = "SAMUE";
}

else if($Chapel == "Nehemiah"){
   $myChapel = "NEHEM";
}

else if($Chapel == "Phillipians"){
   $myChapel = "PHILL";
}

else if($Chapel == "Ephesians"){
   $myChapel = "EPHES";
}

else if($Chapel == "Galatians"){
   $myChapel = "GALAT";
}

else if($Chapel == "James"){
   $myChapel = "JAMES";
}

else if($Chapel == "Colossians"){
   $myChapel = "COLOS";
}

else if($Chapel == "Luke"){
   $myChapel = "LUKE/";
   
}

else if($Chapel == "Mark"){
   $myChapel = "MARK/";
}

else if($Chapel == "Acts"){
   $myChapel = "ACTS/";
}

else if($Chapel == "Timothy"){
   $myChapel = "TIMOT";
}

else if($Chapel == "Matthew"){
   $myChapel = "MATTH";
}

else if($Chapel == "Joshua"){
   $myChapel = "JOSHU";
}




foreach($records4 as $r4){

     $Mid = $r4->Cid;
     
      $Date2= $r4->Date;
   
  $chapelCode2 = substr($r4->Cid ,4,5);
        
    // echo $Mid;
    // echo $chapelCode2; 
         
         if($chapelCode2 == $myChapel && $Date2 == $SelectedDate ){
   $records3 = array();

// Searching for Member details to display again --------------

if($results3 = mysqli_query($db,"SELECT * FROM membersfile WHERE  Cid = '$Mid' ")){
    
    if($results3->num_rows){
        while($row3 = $results3->fetch_object()){
            $records3[]=$row3;
        }
        $results3->free();
        
    }

}

if(! count($records3)){
    echo 'No Match Records Foundoooo...';
}else{
    
   $chapelCount++;
}

// Printing Names -----------------
           foreach($records3 as $r3){
               $counting++;
       print("<ul data-role=\"listview\" data-inset=\"true\">");
                                                 
                            print("<li data-ibm-jquery-contact=\"".($r3->Cid)."\">");
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"members_details.php?action=".($r3->Cid)."&activity=john\">");                           
                            print("".($r3->CFName)." ".($r3->CLName)."<br/>");
                            print("</a>");
                            print("</li>\n");  

                           

                          $test = array('var1'=>$numberholder, 'var2'=>($r3->CContact));
                          $numberholder =  $test['var1'].",". $test['var2'];
                         
                              
                                              
                    print("</ul>");      
           }
        
     }
   
     }
     
?>


<br>
<hr>
        <?php
         if($counting == '0'){
              $DayService = "Sunday";
              $ServiceDate = $SelectedDate;
        
              $_SESSION['WEB_SES'] = $DayService . "^" . $ServiceDate; 
              
               print("<ul data-role=\"listview\" data-inset=\"true\">");
                        print("<li data-ibm-jquery-contact=\"\">");
                                    
                            print("<a data-ajax=\"false\" data-transition=\"pop\"href=\"attendance2.php\">");  
                             print("Record Attendance"."<br/>");
                            print("</a>");
                            print("</li>\n");  
                         
                    print("</ul>");
        echo 'No Member attendance recorded';
         
    }else{
         
        print("No of Attendance = ".($counting)."<br/>");
    }
         
        
        ?>
          </div>
            
          <div data-role="footer" data-position="fixed">
        
               <h2>&copy; All Rights reserved. 2019</h2>
          </div>
    
  </div>    