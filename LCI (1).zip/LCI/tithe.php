
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Vertical (basic) form</h2>
  <form action="tithe_sms.php" method="post">
    <!--<div class="form-group">-->
    <!--  <label for="name">Customer Name:</label>-->
    <!--  <input type="text" class="form-control" id="name" placeholder="Enter Customer Name" name="name">-->
    <!--</div>-->
    <div class="form-group">
      <label for="no">Contact No:</label>
      <input type="text" class="form-control" id="no" placeholder="Enter Contact Number" name="no">
    </div>
    
     <div class="form-group">
      <label for="message">Message:</label>
      <input type="text" class="form-control" id="message" placeholder="Enter message" name="message">
    </div>
    <!--<div class="form-group">-->
    <!--  <label for="pay">last Payment:</label>-->
    <!--  <input type="text" class="form-control" id="lastpay" placeholder="Enter last Payment" name="lastpay">-->
    <!--</div>-->
    <!--<div class="form-group">-->
    <!--  <label for="des">Balance:</label>-->
    <!--  <input type="text" class="form-control" id="balance" placeholder="Enter Payment" name="balance">-->
    <!--</div>-->
   
   
   
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

</body>
</html>



