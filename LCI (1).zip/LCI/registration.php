<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
  require 'db/connect.php';
require 'functions/security.php';
sec_session_start();

 
if (login_check($mysqli) == true) {
    
    $logged = 'in';
} else {
    $logged = 'out';
   //header('Location: index.php');
}















//error_reporting(0);


$records2 = array();

if($results2 = mysqli_query($db,"SELECT Cid FROM membersfile ORDER BY id DESC LIMIT 1")){
    
    if($results2->num_rows){
        while($row2 = $results2->fetch_object()){
            $records2[]=$row2;
        }
        $results2->free();
        
    }
    
    
    
    
}

if(! count($records2)){
    echo 'No Match Records Found 1...';
}else{
        
}



if(!empty($_POST)){
    
        echo "starting";
       
        
        $CId = trim($_POST['cid']);
        $CFName = trim($_POST['CFName']);
        $CLName = trim($_POST['CLName']);
        $CContact = trim($_POST['CContact']);
        $CGender = trim($_POST['CGender']);
        $CBranch = trim($_POST['CBranch']);
        
       

        $bdate = trim($_POST['BDate']);
        
        $BYear = substr($bdate, 0, 4);//yyyy/mm/dd
         $BMon = substr($bdate, 5, 2);//mm
         $Bday = substr($bdate, 8, 2);//yyyy
        
         $rdate = trim($_POST['RDate']);
        $CYear = substr($rdate, 0, 4);//dd
         $CMon = substr($rdate, 5, 2);//mm
         $CDay = substr($rdate, 8, 2);//yyyy
         
         
        
        
        $thanks = date( "Y-m-d", strtotime( "$rdate +1 day" ) ); // PHP:  08-03-04
        
       $welcome = date( "Y-m-d", strtotime( "$rdate +14 day" ) ); // PHP:  08-03-04
        
        $message1 = date("Y-m-d", strtotime( "$rdate +1 month" ) ); //PHP:08-03-04
        
        $message2= date( "Y-m-d", strtotime( "$rdate +2 month" ) ); // PHP:  08-03-04
        
         $message3= date("Y-m-d", strtotime( "$rdate +3 month" ) ); // PHP:  08-03-04
        
         $message4= date("Y-m-d", strtotime( "$rdate +4 month" ) ); // PHP:  08-03-04
        
         $message5= date("Y-m-d",  strtotime( "$rdate +5 month" ) ); // PHP:  08-03-04
       
         $message6= date("Y-m-d", strtotime( "$rdate +6 month" ) ); // PHP:  08-03-04
        
         $message7= date( "Y-m-d", strtotime( "$rdate +7 month" ) ); // PHP:  08-03-04
        
         $message8= date("Y-m-d", strtotime( "$rdate +8 month" ) ); // PHP:  08-03-04
        
         $message9= date( "Y-m-d", strtotime( "$rdate +9 month" ) ); // PHP: 08-03-04
        
         $message10= date("Y-m-d",  strtotime( "$rdate +10 month" ) ); // PHP:  08-03-04
        
         $message11= date( "Y-m-d", strtotime( "$rdate +11 month" ) ); // PHP:  08-03-04
         
     
      
    
    // function GetImageExtension($imagetype){
    //   if(empty($imagetype)) return false;
    //   switch($imagetype)

    //   {
    //       case 'image/bmp': return '.bmp';
    //       case 'image/gif': return '.gif';
    //       case 'image/jpeg': return '.jpg';
    //       case 'image/png': return '.png';
    //       default: return false;
    //   }
 
    //  }

        
        
        if(!empty($CId)&& !empty($CFName) && !empty($CLName) && !empty($CContact) && !empty($CDay) && !empty($CMon) && !empty($CYear)&& !empty($Bday)&& !empty($BMon)&& !empty($BYear)&& !empty($thanks)&& !empty($welcome)&& !empty($CBranch)&& !empty($message1)&& !empty($message2)&& !empty($rdate)&& !empty($bdate) && !empty($message3) && !empty($message4) && !empty($message5) && !empty($message6) && !empty($message7)  && !empty($CGender) && !empty($message8) && !empty($message9) && !empty($message10) && !empty($message11)){
         
         
         
if($results1 = mysqli_query($db,"SELECT * FROM membersfile WHERE CContact = '$CContact'")){
    
    if($results1->num_rows){
        while($row1 = $results1->fetch_object()){
            $records1[]=$row1;
        }
        $results1->free();
        
    }
    
    
    
    
}

if(! count($records1)){
          $insert = $db->prepare("INSERT INTO membersfile (Cid, CFName,CLName, CContact, CDay, CMon, CYear, BDay, BMon, BYear, thanks, welcome, CBranch, message1 ,CGender, message2,RDate , BDate, message3, message4, message5, message6, message7, message8, message9, message10, message11) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $insert->bind_param('sssssssssssssssssssssssssss', $CId,$CFName,$CLName, $CContact,$CDay,$CMon, $CYear, $Bday, $BMon,$BYear,$thanks, $welcome, $CBranch, $message1, $CGender,$message2,$rdate,$bdate,$message3, $message4, $message5, $message6, $message7, $message8, $message9, $message10, $message11);
                echo $message11; 


// }else
{

  // exit("Error While uploading image on the server");
}

            
            if($insert->execute ()){
                ?>
               <script>

setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/LCI/registration.php"; 
}, 1000);
alert("New Member has been successfully registered");

</script>
<?php
            }
            
          
            
        } else{
        ?>
        <script>
            setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/LCI/registration.php"; 
}, 5000);
alert("This member has already been registred");
            
        </script>
      <?php
        }

}else{
    
   
}
         
}        
         
         
           

      
?>

<!DOCTYPE HTML>


<html>
 <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
    <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
       <script>
       
       
      
       </script>
</head>
    
    
    
    
    <body>
       
<div data-role="page" id="register" data-theme="d" >
    
            <div data-role="header" data-theme="d" >
                
                <h4>Customer Register</h4>
                 <div data-role="navbar">
        
        <ul>
        <li><a href= "mainmenu.php">Dash Board</a></li>
       
        
        </ul>
            </div> 
            </div> 
    
 <div data-role="content" data-theme="d">
               
     <form action="" enctype="multipart/form-data" method="POST" data-ajax = "false">
                    <h4>Kindly complete this form to register a new Member.</h4>
                      
         <label for="Cid">ID Number: </label>
                       
         <input type="text" id ="Cid" name="Cid" placeholder="Enter Customer's ID.." disabled>
                      
         <br>
          <select name="CBranch" id="CBranch">
         <option value="">Select Chapel</option>
         <option value="Acts">Acts</option>
         <option value="Colossians">Colossians</option>
         <option value="Corinthians">Corinthians</option>
          <option value="Ephesians">Ephesians</option>
         <option value="Exodus">Exodus</option>
         <option value="Galatians">Galatians</option>
          <option value="Genesis">Genesis</option>
          <option value="Hebrews">Hebrews</option>
          <option value="James">James</option>
           <option value="Joel">Joel</option>
         <option value="John">John</option>
          <option value="Joshua">Joshua</option>
          <option value="Jude">Jude</option>
          <option value="Kings">Kings</option>
          <option value="Luke">Luke</option>
          <option value="Mark">Mark</option>
          <option value="Matthew">Matthew</option>
          <option value="Nehemiah">Nehemiah</option>
         <option value="Peter">Peter</option>
          <option value="Philemon">Philemon</option>
         <option value="Phillipians">Phillipians</option>
         <option value="Revelations">Revelations</option>
         <option value="Romans">Romans</option>
         <option value="Samuel">Samuel</option>
          <option value="Timothy">Timothy</option>
         

         
         </select>
         
                    
                       
         <label for="Cfname">First Name:</label>
                       
         <input type="text" id ="CFName" name="CFName"placeholder="Enter Customer's first name.." onchange="myFunction()">
                      
         <br>
              <label for="Clname">Last Name:</label>
                       
         <input type="text" id ="CLName" name="CLName"placeholder="Enter Customer's last name..">
                      
         <br>       
                      
         <label for="Ccontact">Phone Number:</label>
                      
         <input type="text" id ="CContact" name="CContact"placeholder="Enter Customer's contact number.">
                   
                    
         <br>
         
         
         <label for="bday">Date of Birth:</label>
         
         <input type="date" name="BDate" id="BDate" value = "-">
         
         <br>
        
         
         <label for="regday">Date of Registration:</label>
         
         <input type="date" name="RDate" id="RDate">
         <br>
         <br>
         
        
         
          <select name="CGender" id="CGender">
         <option value="">Select Gender</option>
         <option value="Male">Male</option>
         <option value="Female">Female</option>
         </select>
         <br>
         <br>
         
        
         
         <br>
         <br>
         <br>
         <input type="hidden" name="cid" id="cid" value="" />
         
        <input type="submit" id ="create" value="Register">
        
        
       
                       
                </form>
     
            </div>
            
            <script>
                function myFunction() {
    <?php
    
    ?>
   var typeSelect = document.getElementById("CBranch");
   
 
var selectedType = typeSelect.options[typeSelect.selectedIndex].text;

  
  
if(selectedType == 'Acts'){
     var yyy = "ACTS";
}else if(selectedType == 'Colossians'){
    var yyy = "COLOSSIANS";
}else if(selectedType == 'Corithians'){
    var yyy = "CORITHIANS";
}else if(selectedType == 'Exodus'){
    var yyy = "EXODUS";
}else if(selectedType == 'Galatians'){
    var yyy = "GALATIANS";
}else if(selectedType == 'Genesis'){
    var yyy = "GENESIS";
}else if(selectedType == 'Hebrews'){
    var yyy = "HEBREWS";
}else if(selectedType == 'James'){
    var yyy = "JAMES";
}else if(selectedType == 'Joel'){
    var yyy = "JOEL";
}else if(selectedType == 'John'){
     var yyy = "JOHN";
}else if(selectedType == 'Joshua'){
     var yyy = "JOSHUA";
}else if(selectedType == 'Jude'){
     var yyy = "JUDE";
}else if(selectedType == 'Kings'){
     var yyy = "KINGS";
}else if(selectedType == 'Nehemiah'){
    var yyy = "NEHEMIAH";
}else if(selectedType == 'Peter'){
    var yyy = "PETER";
}else if(selectedType == 'Philemon'){
    var yyy = "PHILEMON";
}else if(selectedType == 'Phillipians'){
    var yyy = "PHILLIPIANS";
}else if(selectedType == 'Revelations'){
    var yyy = "REVELATIONS";
}else if(selectedType == 'Romans' ){
    var yyy = "ROMANS";
}else if(selectedType == 'Samuel' ){
    var yyy = "SAMUEL";
}else if(selectedType == 'Timothy'){
    var yyy = "TIMOTHY";
}else if(selectedType == 'Ephesians'){
    var yyy = "EPHESIANS";
}else if(selectedType == 'Colossians'){
    var yyy = "COLOSSIANS";
}else if(selectedType == 'Luke'){
    var yyy = "LUKE";
}else if(selectedType == 'Mark'){
    var yyy = "MARK";
}else if(selectedType == 'Matthew'){
    var yyy = "MATTHEW";
}else{
    alert("Please select the Chapel");
    
    document.getElementById("CFName").value ='';
    
}
   // alert(yyy);
    <?php
    
     foreach($records2 as $r2){ 
         
         $code = $r2->Cid; //fetching record frm database ------------
         $ttt = substr($code ,-3);  //Picking the last four digits eg 0001
         
         $aaa = 001; // Picking the number 1
         $re = $ttt + $aaa; // Adding one to the number above
         $ff = str_pad($re, 3, '0', STR_PAD_LEFT); //adding two zero's
        echo $ttt;
        // 
         
     } ?>
     
  
     document.getElementById("Cid").value ="LCI/"+yyy+"/"+"<?php echo ("$ff"); ?>";
     document.getElementById("cid").value ="LCI/"+yyy+"/"+"<?php echo ("$ff"); ?>";
    
    document.getElementById("Cid").disabled = true;
    //document.getElementById("cid").disabled = true;
    
}

                
                
                
            </script>
    
           <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>   
</div>
        
        
        
        
        
        
        
        
        
       
    </body>
</html>