<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
  require 'db/connect.php';
require 'functions/security.php';
sec_session_start();

 
if (login_check($mysqli) == true) {
    
    $logged = 'in';
} else {
    $logged = 'out';
  header('Location: index.php');
}

?>




<html>
 <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
   
</head>
    
    
    
    
    <body>
       
<div data-role="page" id="register" data-theme="d" >
    
            <div data-role="header" data-theme="d" >
                
                <h4>Members Attendance Register</h4>
                 <div data-role="navbar">
        
        <ul>
        <li><a href= "mainmenu.php">Dash Board</a></li>
       
        
        </ul>
            </div> 
            </div> 
    
 <div data-role="content" data-theme="d">
    
               
    <p><b></b>Select the Service Type and Date to continue to clock in your Members attendance.</b></p>
    <br>
    
        <form action="attendance.php" enctype="multipart/form-data" method="POST" data-ajax = "false">
    
          <select name="Service" id="Service">
         <option value="">Select Type of Service</option>
         <option value="Wednesday">Wednesday</option>
         <option value="Sunday">Sunday</option>
         </select>
         <br>
        
        
         
         <label for="RDate">Date of Service:</label>
         
         <input type="date" name="RDate" id="RDate">
         <br>
         
         
        
        <hr> 
         
        
         
        
        <input type="submit" id ="submit" value="Submit">
        
        </form>
       
                       
                </form>
     
            </div>
    
            <div data-role="footer" data-position="fixed">
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>   
</div>
        
        
        
        
        
        
        
        
        
       
    </body>
</html>