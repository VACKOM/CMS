<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
  require 'db/connect.php';
require 'functions/security.php';
sec_session_start();

 
if (login_check($mysqli) == true) {
    
    $logged = 'in';
} else {
    $logged = 'out';
   //header('Location: index.php');
}















//error_reporting(0);


// $records2 = array();

// if($results2 = mysqli_query($db,"SELECT Cid FROM membersfile ORDER BY id DESC LIMIT 1")){
    
//     if($results2->num_rows){
//         while($row2 = $results2->fetch_object()){
//             $records2[]=$row2;
//         }
//         $results2->free();
        
//     }
    
    
    
    
// }

// if(! count($records2)){
//     echo 'No Match Records Found 1...';
// }else{
        
// }



if(!empty($_POST)){
    
        
       
        
        
        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $tel = trim($_POST['tel']);
        $area = trim($_POST['area']);
        $chapel = trim($_POST['chapel']);
        
        $date = date('Y-m-d');
       

      echo $tel;

        
        
        if(!empty($fname) && !empty($lname) && !empty($tel) && !empty($area) && !empty($chapel)){
         
         
         
if($results1 = mysqli_query($db,"SELECT * FROM swollen_sunday WHERE tel = '$tel'")){
    
    if($results1->num_rows){
        while($row1 = $results1->fetch_object()){
            $records1[]=$row1;
        }
        $results1->free();
        
    }
    
    
    
    
}

if(! count($records1)){
          $insert = $db->prepare("INSERT INTO swollen_sunday (fname,lname,tel, area, chapel, date) VALUES (?,?,?,?,?,?)");
            $insert->bind_param('ssssss', $fname,$lname,$tel, $area,$chapel,$date);
                //echo $message11; 


// }else
{

  // exit("Error While uploading image on the server");
}

            
            if($insert->execute ()){
                ?>
               <script>

setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/LCI/swollen_sunday.php"; 
}, 1000);
alert("New Invitee has been successfully registered");

</script>
<?php
            }
            
          
            
        } else{
        ?>
        <script>
            setTimeout(function()
{ 
     window.location = "https://condrasolutions.com/LCI/swollen_sunday.php"; 
}, 5000);
alert("This invitee has already been registred");
            
        </script>
      <?php
        }

}else{
    
   
}
         
}        
         
         
           

      
?>

<!DOCTYPE HTML>


<html>
 <head>
	<title> LCI</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
    <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon"> 
    <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
       <script>
       
       
      
       </script>
</head>
    
    
    
    
    <body>
       
<div data-role="page" id="register" data-theme="d" >
    
            <div data-role="header" data-theme="d" >
                
                <h4>Swollen Sunday Invitation</h4>
                 <div data-role="navbar">
        
        <ul>
        <li><a href= "mainmenu.php">Dash Board</a></li>
       
        
        </ul>
            </div> 
            </div> 
    
 <div data-role="content" data-theme="d">
               
     <form action="" enctype="multipart/form-data" method="POST" data-ajax = "false">
                    <h4>Kindly complete this form to register a new invitee.</h4>
                      
        

          <select name="chapel" id="chapel">
         <option value="">Select Chapel</option>
         <option value="Acts">Acts</option>
         <option value="Colossians">Colossians</option>
         <option value="Corinthians">Corinthians</option>
          <option value="Ephesians">Ephesians</option>
         <option value="Exodus">Exodus</option>
         <option value="Galatians">Galatians</option>
          <option value="Genesis">Genesis</option>
          <option value="Hebrews">Hebrews</option>
          <option value="James">James</option>
           <option value="Joel">Joel</option>
         <option value="John">John</option>
          <option value="Joshua">Joshua</option>
          <option value="Jude">Jude</option>
          <option value="Kings">Kings</option>
          <option value="Luke">Luke</option>
          <option value="Mark">Mark</option>
          <option value="Matthew">Matthew</option>
          <option value="Nehemiah">Nehemiah</option>
         <option value="Peter">Peter</option>
          <option value="Philemon">Philemon</option>
         <option value="Phillipians">Phillipians</option>
         <option value="Revelations">Revelations</option>
         <option value="Romans">Romans</option>
         <option value="Samuel">Samuel</option>
          <option value="Timothy">Timothy</option>
         <option value="Others">Others</option>

         
         </select>
         
                    
                       
         <label for="fname">First Name:</label>
                       
         <input type="text" id ="fname" name="fname"placeholder="Enter Invitee's first name..">
                      
         <br>
                        
         <label for="lname">Last Name:</label>
                       
         <input type="text" id ="lname" name="lname"placeholder="Enter Invitee's last name..">
                      
         <br>
                 
                      
         <label for="tel">Phone Number:</label>
                      
         <input type="text" id ="tel" name="tel"placeholder="Enter Invitee's contact number.">
                   
                    
         <br>
         
        
         
         <select name="area" id="area">
         <option value="">Select Area</option>
         <option value="Amanfrom Top Town">Amanfrom Top Town</option>
         <option value="Aplaku">Aplaku</option>
         <option value="Ash Bread">Ash Bread</option>
         <option value="Bortianor">Bortianor</option>
         <option value="Bulemi">Bulemi</option>
          <option value="Choice">Choice</option>
         <option value="Galilea">Galilea</option>
         <option value="Gbawe">Gbawe</option>
         <option value="Krokrobite">Krokrobite</option>
         <option value="Liberia Camp">Liberia Camp</option>
         <option value="New Bortinaor">New Bortinaor</option>
         <option value="Oblogo">Oblogo</option>
         <option value="Sampa Valley">Sampa Valley</option>
          <option value="SCC">SCC</option>
          <option value="Schools">Schools</option>
         <option value="Tetegu">Tetegu</option>
         
         

         
         </select>
         
         
          
         
        
         
         <br>
         <br>
         <br>
       
         
        <input type="submit" id ="create" value="Register">
        
        
       
                       
                </form>
     
            </div>
            
           
    
           <div data-role="footer" data-position="fixed">
        
               <h2>Condra Solutions 2019 &copy; All Rights reserved</h2>
          </div>   
</div>
        
        
        
        
        
        
        
        
        
       
    </body>
</html>