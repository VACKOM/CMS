             
             $("#numbers").append('<li><?php echo ($r->EHead); ?></li>' );
             $('#numbers').listview('refresh');
             
            