<!DOCTYPE HTML>

<?php

    
//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';



if(!empty($_POST['CIdSearch'])){


$search = $_POST['CIdSearch'];

$_POST['CIdSearch'] = '';
    
   
$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile WHERE CId='$search'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}

?>

<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
   
	<link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>

<body>
        
    
    <div data-role="page" id="SingleSearch" data-theme="d"  >
        <div data-role="header" data-theme="d">
            
        <h1> Search Results</h1>
            
          
    
        
        </div>
        
        <?php
if(! count($records)){
    echo 'No Match Records Found...';
}else{
   
?>
       
        
        <br>
        
        
        <table>
        <thead>
            <tr>
               <th> </th>
               <th> </th>
            
            </tr>
            
        </thead>
        
           
                <tbody>
                <?php
    foreach($records as $r){
                 ?>
                
                
                
               <tr>
                  
                  <td><img src="<?php echo ($r->photo); ?>" height="250" width = "250"</td>
                   
               </tr>
                <?php
                }
                ?>
                
            </tbody>
            
             <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                <?php
    foreach($records as $r){
                 ?>
                
                
                
               <tr>
                  <td><b>ID Number:  </b></td>
                  <td><?php echo ($r->CId); ?></td>
                   
               </tr>
                <?php
                }
                ?>
                
            </tbody>
            
             <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Name:  </b></td>
                  <td><?php echo ($r->CFName); ?>  <?php echo ($r->CLName); ?></td>
               </tr>
                <?php
                }
                ?>
            </tbody>
           
             <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Contact:  </b></td>
                  <td><a href = "tel:<?php echo ($r->CContact); ?>"> <?php echo ($r->CContact); ?></a></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Email:  </b></td>
                  <td><?php echo ($r->CEmail); ?></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
    
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Registeration Date:  </b></td>
                  <td><?php echo ($r->RDate); ?></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
        
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            
            <tbody>
                
               <tr>
                  <td>   </td>
                  <td>   </td>
                   
               </tr>
             </tbody>
            <tbody>
              <?php
    foreach($records as $r){
                 ?>
               <tr>
                  <td><b>Ministry:  </b></td>
                  <td><?php echo ($r->CBranch); ?></td>
                   
               </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
        <?php
        }
}



if(!empty($_POST['CNSearch'])){


$search = $_POST['CNSearch'];
  
    $_POST['CNSearch'] = '';
    
$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile  WHERE CLName='$search' ")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}

?>

<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
   
	<link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>

<body>
        
    
    <div data-role="page" id="SingleSearch" data-theme="d"  >
        <div data-role="header" data-theme="d">
            
        <h1> Search Results</h1>
            
          
    
        
        </div>
        
        
        <br>
        <br>
        <br>
        <?php
if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
    echo 'Customers with Surname: ';
    echo $search;
    
    ?>
        <br>
        
        <?php
    
     foreach($records as $r){
         
         
         ?>
        
            
            
                            
          <select name="select" id ="choice">
              <?php ($count++);?> 
<option value="Option 1"> <?php echo ($r->CFName);?>  <?php echo ($r->CLName);?></option>
<option value="Option 2">Customer ID Number: <?php echo ($r->CId);?></option>
<option value="Option 3">Contact Number: <a href = "tel:<?php echo ($r->CContact); ?>"> <?php echo ($r->CContact); ?></a></option>
              
<option value="Option 4">Email Address: <?php echo ($r->CEmail);?></option>
 <option value="Option 5">Ministry: <?php echo ($r->CBranch);?></option>             
</select>
         
         
    
         <?php
        
     }
   
?>
       
        
        <br>
        
        
        
        <?php
    echo 'Total Number of Customers  : ';
    
    echo $count;
        }
}



if(!empty($_POST['CRDSearch'])){


$Search = $_POST['CRDSearch'];
$search = new DateTime($Search);
$search = $search->format('d-m-Y'); // 31-07-2012
 
    $_POST['CRDSearch'] = '';
    
$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile  WHERE RDate='$search' ")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}

?>

<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
   <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>

<body>
        
    
    <div data-role="page" id="SingleSearch" data-theme="d"  >
        <div data-role="header" data-theme="d">
            
        <h1> Search Results</h1>
            
          
    
        
        </div>
        <br>
        <br>
        <br>
        <?php
if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
    echo 'Customers registered on: ';
    echo $search;
    
    ?>
        <br>
        
        <?php
    
     foreach($records as $r){
         
         
         ?>
        
            
             
                            
          <select name="select" id ="choice">
              <?php ($count++);?> 
<option value="Option 1"><?php echo ($r->CFName);?>  <?php echo ($r->CLName);?></option>
<option value="Option 2">Customer ID Number: <?php echo ($r->CId);?></option>
<option value="Option 3">Contact Number: <?php echo ($r->CContact);?></option>
<option value="Option 4">Email Address: <?php echo ($r->CEmail);?></option>
 <option value="Option 5">Ministry: <?php echo ($r->CBranch);?></option>             
</select>
         
         
    
         <?php
        
     }
   
?>
       
        
        <br>
        
        
        
        <?php
    echo 'Total Number of Customers registered : ';
    
    echo $count;
    
        }
}



if(!empty($_POST['CRMSearch'])){


$search = $_POST['CRMSearch'];
$year = $_POST['CRYSearch'];
    echo $search;
    echo $year;
 
    $_POST['CRMSearch'] = '';
     $_POST['CRYSearch'] = '';
    
$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile  WHERE CMon='$search' AND CYear='$year'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}

?>

<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
   <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>

<body>
        
    
    <div data-role="page" id="SingleSearch" data-theme="d"  >
        <div data-role="header" data-theme="d">
            
        <h1> Search Results</h1>
            
          
    
        
        </div>
        <br>
       
        <br>
        <?php
if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
    echo 'Customers registered in: ';
   if( $search == '01'){
     echo 'January  ' ;                  
     echo $year;
                       }
    elseif( $search == '02'){
     echo 'February  ' ;                  
     echo $year;
                       }
    elseif( $search == '03'){
     echo 'March  ' ;                  
     echo $year;
                       }
    elseif( $search == '04'){
     echo 'April  ' ;                  
     echo $year;
                       }
    elseif( $search == '05'){
     echo 'May  ' ;                  
     echo $year;
                       }
    elseif( $search == '06'){
     echo 'June  ' ;                  
     echo $year;
                       }
    elseif( $search == '07'){
     echo 'July  ' ;                  
     echo $year;
                       }
    elseif( $search == '08'){
     echo 'August  ' ;                  
     echo $year;
                       }
    elseif( $search == '09'){
     echo 'September  ' ;                  
     echo $year;
                       }
    elseif( $search == '10'){
     echo 'October  ' ;                  
     echo $year;
                       }
    elseif( $search == '11'){
     echo 'November  ' ;                  
     echo $year;
                       }
    elseif( $search == '12'){
     echo 'December  ' ;                  
     echo $year;
                       }
    ?>
        <br>
        
        <?php
    
     foreach($records as $r){
         
         
         ?>
        
            
             
                            
          <select name="select" id ="choice">
              <?php ($count++);?> 
<option value="Option 1"><?php echo ($r->CFName);?>  <?php echo ($r->CLName);?></option>
<option value="Option 2">Customer ID Number: <?php echo ($r->CId);?></option>
<option value="Option 3">Contact Number: <?php echo ($r->CContact);?></option>
<option value="Option 4">Email Address: <?php echo ($r->CEmail);?></option>
 <option value="Option 5">Ministry: <?php echo ($r->CBranch);?></option>             
</select>
         
         
    
         <?php
        
     }
   
?>
       
        
        <br>
        
        
        
        <?php
    echo 'Total Number of Customers registered : ';
    
    echo $count;
        }
}



if(!empty($_POST['CRYYSearch'])){


$search = $_POST['CRYYSearch'];

 
    $_POST['CRYYSearch'] = '';
    
$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile  WHERE CYear='$search' ")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
}
else{
    echo "Wrong Email or Password entered. Please check";
 
        
}

?>

<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes" />
    	
   <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
	
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>	
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
	<link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       
       
</head>

<body>
        
    
    <div data-role="page" id="SingleSearch" data-theme="d"  >
        <div data-role="header" data-theme="d">
            
        <h1> Search Results</h1>
            
          
    
        
        </div>
        <br>
        <br>
        <br>
        <?php
if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
    echo 'Customers registered in: ';
    echo $search;
    
    ?>
        <br>
        
        <?php
    
     foreach($records as $r){
         
         
         ?>
        
            
             
                            
          <select name="select" id ="choice">
              <?php ($count++);?> 
<option value="Option 1"><?php echo ($r->CFName);?>  <?php echo ($r->CLName);?></option>
<option value="Option 2">Customer ID Number: <?php echo ($r->CId);?></option>
<option value="Option 3">Contact Number: <?php echo ($r->CContact);?></option>
<option value="Option 4">Email Address: <?php echo ($r->CEmail);?></option>
 <option value="Option 5">Ministry: <?php echo ($r->CBranch);?></option>             
</select>
         
         
    
         <?php
        
     }
   
?>
       
        
        <br>
        
        
        
        <?php
    echo 'Total Number of Customers registered : ';
    
    echo $count;
    
        }
}





        ?>
        <hr>
        <br>
       
        <br>
       
        <br>
         <hr>
        <br>
       
        
        
        
         
        
        
        <div data-role="footer" data-position="fixed">
        
        <h2>&copy; All Rights reserved. 2014</h2>
        </div>
        
        
  </div>
        
       
    </body>

</html>