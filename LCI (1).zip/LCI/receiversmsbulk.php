<?php

require 'db/connect.php';
require 'functions/security.php';
?>

<!DOCTYPE html>
<html>
<head>
   
 
    <title> CMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-heigh, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes" />
        
 <link rel="stylesheet" href="themes/finalTheme.css" />
    <link rel="stylesheet" href="themes/finalTheme.min.css" />
    
   
    <title>Modex Mobile</title>
    <script class="cssdeck" src="jquery/jquery-2.1.1.min.js"></script>  
    <script class="cssdeck" src="jquery/jquery.mobile-1.4.2.min.js"></script>

    <link rel="stylesheet" href="jquery/jquery.mobile-1.4.2.min.css" media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.icons-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/jquery.mobile.inline-svg-1.4.2.min.css"  media="screen"/>
    <link rel="stylesheet" href="jquery/style.css" />
    <link href="" rel="shortcut icon">        
       

       
</head>
    <body>
    <div data-role="page" id="register" data-theme="d" >
    
            <div data-role="header" data-theme="d" >
                
                
                 <div data-role="navbar">
        
        <ul>
        <li><a href= "schedules.php">Daily Schedule</a></li>
       
        
        </ul>
            </div> 
            </div> 
    
 <div data-role="content" data-theme="d">

 <button onclick="window.location.href='schedules.php'">Schedule Details</button>
    <?php
	$receiver = htmlentities(isset($_GET['phonenumber']) ? @$_GET['phonenumber'] : @$_POST['phonenumber']);
	$message = htmlentities(isset($_GET['message']) ? @$_GET['message'] : @$_POST['message']);
	$sender = htmlentities(isset($_GET['senderid']) ? @$_GET['senderid'] : @$_POST['senderid']);
	
	
	$key="PMUy4AuY279e3RZqfNKB5aSk1"; //your unique API key
$message=urlencode($message); //encode url
$url="http://sumafo.sinitsolutions.org/api/sendsms.php?key=$key&receiver=$receiver&message=$message&sender=$sender";
$result=file_get_contents($url); //call url and store result;
switch($result){ 
case "successful": 






$sql = "UPDATE customerfile SET thanks='2037-12-31' WHERE CContact=$receiver";

if (mysqli_query($db, $sql)) {
    echo "Message sent";
} else {
    echo "Error updating record: " . mysqli_error($db);
}

mysqli_close($db);


break;
case "failed":
echo "Message not sent";
break;
case "insufficient balance": 
echo "You don't have jnm,m,n,enough balance";
break;
case "invalid API key": 
echo "Invalid API Key";
break; 
}
?>
</div>
</body>
</html>