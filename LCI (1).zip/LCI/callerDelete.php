<!DOCTYPE HTML>

<?php

    
//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';

if(isset($_POST['CId']))
{


$search = ($_POST['CId']);
$sql = "UPDATE customerfile SET thanks='2037-12-31' WHERE CId='$search'";

if (mysqli_query($db, $sql)) {
    echo "done";
} else {
     echo "Error updating record ssssssssssss: " . mysqli_error($db);
}
}else{
echo "no ID Found";
}
?>
