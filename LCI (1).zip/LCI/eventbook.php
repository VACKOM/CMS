<!DOCTYPE HTIML>

<?php

    
//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';



if(!empty($_POST)){
    
        
       
        
        $EHead = trim($_POST['EHead']);
        $EDes = trim($_POST['EDes']);
        $ELoc = trim($_POST['ELoc']);
        $EOrg = trim($_POST['EOrg']);
        $ECont = trim($_POST['ECont']);
        $EStart = trim($_POST['EStart']);
        $EEnd = trim($_POST['EEnd']);
        $ETime1 = trim($_POST['ETime1']);
        $ETime2 = trim($_POST['ETime2']);
       
        
        
        if(!empty($EHead)&& !empty($EDes) && !empty($ELoc) && !empty($EOrg) && !empty($ECont) && !empty($EStart) && !empty($EEnd)&& !empty($ETime1)&& !empty($ETime2)){


            $insert = $db->prepare("INSERT INTO events (EHead, EDes, ELoc, EOrg, ECont, EStart, EEnd, ETime1, ETime2) VALUES (?,?,?,?,?,?,?,?,?)");
            $insert->bind_param('sssssssss', $EHead,$EDes,$ELoc, $EOrg,$ECont,$EStart, $EEnd, $ETime1, $ETime2);
                


}else{

   exit("Error While uploading image on the server");
}

            
            if($insert->execute ()){
           
            header('Location: eventbook.php');
            }
            
          
            
        }
       else{echo 'NO';} 
    

?>




<html>
<head>
	<title> CMS</title>
    <meta charset="utf-8">
	
       
       
</head>
    <body>
<div data-role="page" id="schedule" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Event Organizer</h4>
         <div data-role="navbar">
         <ul>
         <li><a href= "mainmenu.php">Dash Board</a></li>
         </ul>
         </div> 
    </div>
    
     
        
          <div data-role="content">

        <ul data-role="listview" data-inset="true" data-theme="d">
        <li data-role="list-divider">Sub Menu</li>
            <li><a href= "#Add">Add Events</a></li>
            <li><a href= "eventviewer.php">View Events</a></li>      
            <li><a href= "">Edit Events</a></li>
            <li><a href= "#CustRegDate">Cancel Events</a></li>
            
        </ul>
    
        </div>
        
        
      
  
    
  </div>
        
        
        <div data-role="page" id="Add" data-theme="d" >
    <div data-role="header" data-theme="d" >
         <h4>Add This Event</h4>
         <div data-role="navbar">
        
         </div> 
    </div>
    
     <div data-role="content">
         <form action="" enctype="multipart/form-data" method="POST" data-ajax = "false">
         
         <label for="ehead"><center><h4><b><i>Headline & Description</i></b></h4></center></label>
                       
    <input type="text" id ="EHead" name="EHead"placeholder="Event Headline......">
         
        
    <textarea name="EDes" id = "EDes" cols="4" rows="4" maxlength="300"  
    placeholder="Event Description ........."></textarea>   
         <br>
         <br>
         
     <label for="eloc"><b>Event Location:</b></label>
                       
      <input type="text" id ="ELoc" name="ELoc"placeholder="Location....">
                      
    <br> 
         
    <label for="eorg"><b>Organizer:</b></label>
                       
         <input type="text" id ="EOrg" name="EOrg"placeholder="Organizer....">
                      
         <br> 
         
         <label for="econt"><b>Contact Number:</b></label>
                       
         <input type="text" id ="ECont" name="ECont"placeholder="Contact Number....">
                      
         <br> 
         <br>
     <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="Estart"><b>Start Date:</b></label>
                       
         <input type="date" id ="EStart" name="EStart" >
                      
         <br>   
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
         <br>   
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime1"><b>Start Time:</b></label>
                       
         <input type="time" id ="ETime1" name="ETime1" placeholder="Starting Time..">
        

      </div>
      
    </div>
         
       
         
           <div class="ui-grid-b">
      <div class="ui-block-a" style="width:60%">
       
         <label for="Eend"><b>End Date:</b></label>
                       
         <input type="date" id ="EEnd" name="EEnd" placeholder="End Date..">
                      
          
      </div>
         
         <div class="ui-block-b" style="width:5%">
       
         
          
      </div>
         
      <div class="ui-block-c" style="width:35%">
         
        <label for="Etime2"><b>End Time:</b></label>
                       
         <input type="time" id ="ETime2" name="ETime2" placeholder="End Time..">
        

      </div>
      
    </div>
         
         
       <input type="submit" id ="create" value="Generate">  
         
         
         </form>
         
        
            </div>
        </div>
    </body>
</html>