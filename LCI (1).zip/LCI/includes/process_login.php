<?php
include_once 'db_connect.php';
include_once 'functions.php';
require 'db/connect.php';
 
sec_session_start(); // Our custom secure way of starting a PHP session.

if (isset($_POST['email'], $_POST['p'])) {
    $email = $_POST['email'];
    $password = $_POST['p']; // The hashed password.
  
    if (login($email, $password, $mysqli) == true) {
        // Login success 
       // header('Location: ../protected_page.php');
       
       $records = array();
// searching for customer records .......................................

if($results = mysqli_query($db,"SELECT * FROM staff_users WHERE email = '$email'")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
         
         }

//}

foreach($records as $r){
    $control = ($r->control);
   // echo $control;
    if ($control == "user"){
    header('Location: ../mainmenu.php');
    //header('Location: ../customer_register.php');
     }
     else if ($control == "Admin"){
      header('Location: ../admin_mainmenu.php');
    }
    else if ($control == "revenue"){
      header('Location: ../revenueStaff_Menu.php');
    }
}
       
       
       
       
       
       
       
       
       
        
       
    } else {
        // Login failed 
        header('Location: ../index.php?error=1');
    }
} else {
    // The correct POST variables were not sent to this page. 
    echo 'Invalid Request';
}