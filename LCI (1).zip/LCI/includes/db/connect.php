<?php
$db = new mysqli('localhost','gdatzzhm_databaselciadmin','m{b1m!RhMGCW','gdatzzhm_databaselci');

//$db = new mysqli('127.0.0.1','gdatzzhm_jso_admin','MZ5j=Ho]RF#G','gdatzzhm_jso_database');

if($db->connect_errno){
    echo $db->connect_error;
    die('Sorry, we are having some problems.');
}