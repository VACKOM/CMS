<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // The host you want to connect to.
define("USER", "gdatzzhm_databaselciadmin");    // The database username. 
define("PASSWORD", "m{b1m!RhMGCW");    // The database password. 
define("DATABASE", "gdatzzhm_databaselci");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "staff");
 
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!
?>