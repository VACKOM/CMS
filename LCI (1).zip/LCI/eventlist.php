 <?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';

$search = $_POST['EHead'];
  
$records = array();

if($results = mysqli_query($db,"SELECT * FROM events WHERE EHead = $search; ")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    //echo 'No Match Records Found...';
}else{
    
   
}


?>