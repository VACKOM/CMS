<?php

//error_reporting(0);
require 'db/connect.php';
require 'functions/security.php';



    

$records = array();

if($results = mysqli_query($db,"SELECT * FROM Customerfile")){
    
    if($results->num_rows){
        while($row = $results->fetch_object()){
            $records[]=$row;
        }
        $results->free();
        
    }
    
    
    
    
}

if(! count($records)){
    echo 'No Match Records Found...';
}else{
    
   
}
$counting = '1';
$ans = '0';
 foreach($records as $r){
     //echo ($r->thanks);
 


if($counting = 1){
     $now = time(); // or your date as well
     $your_date = strtotime($r->thanks);
     $datediff = $now - $your_date;
     $tank = floor($datediff/(60*60*24));
    
    $counting ++;
    if($tank <= 0 ){
        $ans++;
    }
    echo $ans;
}
 }
?>