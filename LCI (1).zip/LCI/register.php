<?php
include_once 'includes/register.inc.php';
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
       <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>JSO Customer Platform</title>
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script>
         <!-- Bootstrap CSS CDN -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Our Custom CSS -->
        <link rel="stylesheet" href="css/style4.css">
        
         <style>
           a {
              color: blue;
             }
</style>
    </head>
    <body>
         
       
              

                <div class="container">
                 <h3>Staff Register</h2>
                 
                    <div class="line"></div>
 <div class="alert alert-info fade in">
    <a href="#" class="close" data-dismiss="alert">&times;</a>
    <strong>Note!</strong> Fill the form below to register ......
</div>
        <?php
        if (!empty($error_msg)) {
            echo $error_msg;
        }
        ?>
        
        <h4>Registration Form</h4>
        <ul>
            <li>Usernames should contain your full name</li>
            <li>Emails must have a valid email format</li>
            <li>Passwords must be at least 6 characters long</li>
            <li>Passwords must contain
                <ul>
                    <li>At least one uppercase letter (A..Z)</li>
                    <li>At least one lowercase letter (a..z)</li>
                    <li>At least one number (0..9)</li>
                </ul>
            </li>
            <li>Your password and confirmation must match exactly</li>
        </ul>
        <div class="line"></div>
        <form action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" 
                method="post" 
                name="registration_form">
            
            <div class="form-group">
      <label class="control-label col-sm-2" for="username">Username:</label>
      <div class="col-sm-10"> 
      
        <input type="text" class="form-control" id="username" placeholder="Enter your Name..." name="username" value="">
      </div>
    </div>
    
     <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10"> 
      
        <input type="email" class="form-control" id="email" placeholder="Enter your Email Address..." name="email" value="">
      </div>
    </div>
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="password">Password:</label>
      <div class="col-sm-10"> 
      
        <input type="password" class="form-control" id="password" placeholder="Enter your Password..." name="password" value="">
      </div>
    </div>
    
    <div class="form-group">
      <label class="control-label col-sm-2" for="confirmpwd">Confirm Password:</label>
      <div class="col-sm-10"> 
      
        <input type="password" class="form-control" id="confirmpwd" placeholder="Re enter your Password..." name="confirmpwd" value="">
      </div>
    </div>
    
     <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary"  onclick="return regformhash(this.form,
                                   this.form.username,
                                   this.form.email,
                                   this.form.password,
                                   this.form.confirmpwd);"  >Register</button>
      </div>
    </div>       
            <!--Username: <input type='text' -->
            <!--    name='username' -->
            <!--    id='username' />-->
            <!--    <br>-->
                
            <!--Email: <input type="text" name="email" id="email" /><br>-->
            
            <!--Password: <input type="password"-->
            <!--                 name="password" -->
            <!--                 id="password"/><br>-->
                             
            <!--Confirm password: <input type="password" -->
            <!--                         name="confirmpwd" -->
            <!--                         id="confirmpwd" /><br>-->
            <!--<input type="button" -->
            <!--       value="Register" -->
            <!--       onclick="return regformhash(this.form,-->
            <!--                       this.form.username,-->
            <!--                       this.form.email,-->
            <!--                       this.form.password,-->
            <!--                       this.form.confirmpwd);" /> -->
        </form>
        </div>
        <p>Return to the <a href="index.php">login page</a>.</p>
    </body>
</html>