<?php
$db = new mysqli('localhost','gdatzzhm_databaselciadmin','m{b1m!RhMGCW','gdatzzhm_databaselci');

//$db = new mysqli('127.0.0.1','root','root2','databasecms');

if($db->connect_errno){
    echo $db->connect_error;
    die('Sorry, we are having some problems.');
}