<?php

    /*Using MySQL as backend database*/
    $mysql_db = "gdatzzhm_databaselci";
    $mysql_user = "gdatzzhm_databaselciadmin";
    $mysql_pass = "m{b1m!RhMGCW";
    $mysql_connStr = mysql_connect("localhost", $mysql_user, $mysql_pass);

    mysql_select_db($mysql_db, $mysql_connStr);

?>

